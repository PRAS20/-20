export const environment = {
  production: true,
  environmentType:"PROD",
  baseUrl: 'http://hbtmacallocator-env-1.gkpwpcsmeb.us-east-1.elasticbeanstalk.com/api'  
  //baseUrl: 'http://10.219.42.32:8080/api'
  // baseUrl = 'http://localhost:8080/api'
  // baseUrl = 'http://hbtmacallocator-env-1.gkpwpcsmeb.us-east-1.elasticbeanstalk.com/api'
};
