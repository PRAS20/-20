import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OuiPopUpComponent } from './oui-pop-up/oui-pop-up.component';
import { GenerateMacComponent } from './generate-mac/generate-mac.component';
import { OuiRequestedProductComponent } from './oui-requested-product/oui-requested-product.component';
import { ClientGeneratorComponent } from './client-generator/client-generator.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { NotAuthorizedComponent } from './not-authorized/not-authorized.component';
import { OuiStatisticsComponent } from './oui-statistics/oui-statistics.component';
import { AuthGuard } from './auth/auth.guard';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { FaqComponent } from './faq/faq.component';
import { DashboardComponentsComponent } from './dashboard-components/dashboard-components.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
 
  {
    path: '',
    redirectTo: 'mac',
    pathMatch: 'full'
  },
  {
    path:'mac',component:DashboardComponent, children :[
      { path: "", redirectTo: "dashboard", pathMatch: "full",canActivate: [AuthGuard] },
      {
        path:'requested_client',component:OuiPopUpComponent, canActivate: [AuthGuard]
      },
       {
        path:'requested_product',component:OuiRequestedProductComponent, canActivate: [AuthGuard]
      }, 
      {
        path:'dashboard',component:DashboardComponentsComponent
      },
      {
        path:'generate_mac',component:GenerateMacComponent
      },
      {
        path:'client_generator',component:ClientGeneratorComponent
      },
      {
        path:'product_management',component:ProductManagementComponent
      },
      {
        path:'faq',component:FaqComponent
      },
      {
        path:'oui_statistics',component:OuiStatisticsComponent
      },
      {
        path:'pageNotFound',component:PageNotFoundComponent
      },
      { 
        path: "**", pathMatch   : 'full',component: PageNotFoundComponent 
      }
      
    ],
    canActivateChild: [AuthGuard]
    
   },
   {
      path: 'not_authorized',component:NotAuthorizedComponent
   },
   { 
    path: "**", pathMatch   : 'full',component: PageNotFoundComponent 
   },
   { path: "", redirectTo: "generate_mac", pathMatch: "full" }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
