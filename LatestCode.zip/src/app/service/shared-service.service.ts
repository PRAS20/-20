import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class sharedService {

  baseUrl = environment.baseUrl;

  bussinessUnit: any[] = [];
  ouiDetails: any[] = [];
  clientDetails: any[] = [];
  productDetails : any[] = [];
  productRequestDetails : any[] = [];
  clientRequestDetails : any[] = [];
  downloadMACAddressList: any[] = [];
  public navigatepage:boolean=false;
  public pageCount:number=0;
  public checkCondition:boolean=false;
  public popOpenFlag:any=false;
  public popOpenCount:any=0;
  public loginDE:any='';
  constructor(private http: HttpClient) { }

  private handleError(error: HttpErrorResponse) {
    console.log(error);
    // return an observable with a user friendly message
    return throwError('Error! something went wrong.');
  }


  

    getBussinessUnit_api(): Observable<any> {
      const httpOptions = {
        headers: new HttpHeaders({
         'Content-Type':  'application/json',
         'Authorization':  'token'   
        })};

      return this.http.get(`${this.baseUrl}/businessUnit`,httpOptions).pipe(
        map((res: any[]) => {
          this.bussinessUnit = res;
          return this.bussinessUnit;
      })
      );
    }

    getloginDeatails_api(): Observable<any> { 
      return this.http.get(`https://qcwa.honeywell.com/as/authorization.oauth2?client_id=Client_44259&response_type=token&redirect_uri=https://macallocatorqa.honeywell.com/#/`).pipe(
        map((res: any [])=>{
          this.loginDE=res;
          return this.loginDE;
        })
      );
    }


    getOUIDetails_api(): Observable<any> { 
      return this.http.get(`${this.baseUrl}/oui`).pipe(
        map((res: any [])=>{
          this.ouiDetails=res;
          return this.ouiDetails;
        })
      );
    }

    getClientDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/client/tokens/Prasanna`).pipe(
        map((res: any [])=>{
            this.clientDetails=res;
            return this.clientDetails;
        })
      );
    }

    getProductDetails_api(currentBusinssUnit): Observable<any> {
      return this.http.get(`${this.baseUrl}/productLines?businessUnit=${currentBusinssUnit}`).pipe(
        map((res: any[])=>{
          this.productDetails = res;
          return this.productDetails;
        })
      )
    }

    getProductRequestDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/productline/requests`).pipe(
        map((res: any[])=>{
          this.productRequestDetails = res;
          return this.productRequestDetails;
        })
      )
    }

    getProductRequestDetailsForOUI_api(): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type' : 'application/json'
      }); 
      return this.http.get(`${this.baseUrl}/oui`,{
        headers: httpHeaders,
        observe: 'response'
      });
    }

    

    getClientRequestDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/client/requests`).pipe(
        map((res: any[])=>{
          this.clientRequestDetails = res;
          return this.clientRequestDetails;
        })
      )
    }

    downloadMAC_Address_api(dataInput:any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type' : 'application/json'
      }); 
      console.log("data-->",dataInput)
      return this.http.get(`${this.baseUrl}/productline/selfManaged/macids?businessUnit=${dataInput.businessUnit}&productLineName=${dataInput.productLineName}`, {
        headers: httpHeaders,
        observe: 'response',
        responseType: 'blob' as 'json'
      }
      )
    }

    
    downloadProductLine_MACAddress_api(dataInput:any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type' : 'application/json'
      }); 
     
      return this.http.get(`${this.baseUrl}/productline/generatedmacs?businessUnit=${dataInput.businessUnit}&productLineName=${dataInput.productLineName}`, {
        headers: httpHeaders,
        observe: 'response',
        responseType: 'blob' as 'json'
      }
      )
    }

    createClient(dataInput:any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type' : 'application/json'
      }); 
      console.log(dataInput);
      return this.http.post(`${this.baseUrl}/client/request`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      )
    }

    createProductLine(dataInput:any): Observable<any>{
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      console.log(dataInput);
      return this.http.post(`${this.baseUrl}/productLine/request`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      );  
    }

    generateMac(dataInput:any): Observable<any>{
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      console.log(dataInput);
      return this.http.post(`${this.baseUrl}/productline/toolManaged/macids`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      );  
    }

    updateClientRequest(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/client/management`,dataInput,{
        headers: httpHeaders,
        observe: 'response'
        } 
      );    
    }

    updateProductRequest(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/productLine/management`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      );  
       
    }

    updateExistingProduct(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/productLine/management`,dataInput,
      {
        headers: httpHeaders,
        observe: 'response'
      }
      );
    }

    updateExistingClient(dataInput: any): Observable<any>{
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/client/management`,dataInput,
      {
        headers: httpHeaders,
        observe: 'response'
      }
      );
    }

    errorResponse(err) {
      if (err.error instanceof Error) {
        //A client-side or network error occurred.				 
        console.log('An error occurred:', err.error.message);
      } else {
        //Backend returns unsuccessful response codes such as 404, 500 etc.				 
        console.log('Backend returned status code: ', err.status);
        console.log('Response body:', err.error);
      }
    }
  
  
}
