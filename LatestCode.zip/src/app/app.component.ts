import { Component } from '@angular/core';
import { AuthService } from './auth/auth.service'
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';
import { sharedService } from './service/shared-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MAC-ALLOCATOR';
  userRole:any='';
    // LoginAuthentication Implicit Grant Type
    environmentType= environment.environmentType;
    client_id:any='';
    response_type:any='';
    redirect_uri:any='';
    scope:any='';
    state:any='';
    client_secret:any="";
    currentToken: any='';
    authenticationURL_BASE:any ='';
    authorizationToken:any="";



  constructor(
    private router:Router,
    private AuthService:AuthService,
    private DataService:sharedService
    ){
    sessionStorage.setItem('USER_NAME','Test User');
    sessionStorage.setItem('USER_ROLE','ADMIN');
    // sessionStorage.setItem('USER_ROLE','USER');
    this.getLoginDetails();
    this.loginAuthentication();
  }

   loginAuthentication(){

      if(this.authorizationToken!=""){
        
      }else{     
        this.client_id="Client_44259";
        this.response_type="token";
        this.authenticationURL_BASE="https://qcwa.honeywell.com";
        this.client_secret="UHqsE26ohomuejQHaMb7Gy4R7fEM3jMPlJXN8K20L7HwJvbjqWoUsBCzkJ2TKcwj";
        this.redirect_uri="https://macallocatorqa.honeywell.com";
        this.scope="";
        this.state="";

      localStorage.setItem("BaseURL", this.authenticationURL_BASE)


      window.location.href=this.authenticationURL_BASE+'/as/authorization.oauth2?'+'client_id='+this.client_id+'&'+'response_type='+this.response_type+'&'+'redirect_uri='+this.redirect_uri;

      console.log("URL==>",this.authenticationURL_BASE+'/as/authorization.oauth2?'+'client_id='+this.client_id+'&'+'response_type='+this.response_type+'&'+'redirect_uri='+this.redirect_uri)
    
   }

  }

  
  getLoginDetails() {
    if(sessionStorage.getItem('USER_NAME')){
      this.AuthService.isLoggedIn = true;
    } else {
      this.AuthService.isLoggedIn = false;
    }

   
      if(sessionStorage.getItem('USER_ROLE') == 'ADMIN'){
        this.AuthService.isAdmin = true;
        this.AuthService.userRole=sessionStorage.getItem('USER_ROLE');
        this.AuthService.userName=sessionStorage.getItem('USER_NAME');
        console.log("User Role-->",this.AuthService.userName);
        
      } else if(sessionStorage.getItem('USER_ROLE') == 'USER'){
        this.AuthService.isAdmin = false;
        this.AuthService.userRole= sessionStorage.getItem('USER_ROLE');
        this.AuthService.userName=sessionStorage.getItem('USER_NAME');
        console.log("User Role-->",this.AuthService.userName);
      }
    

  }
  
}
