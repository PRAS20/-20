import { Component, OnInit } from '@angular/core';
import  { Router } from '@angular/router';

@Component({
  selector: 'app-not-authorized',
  templateUrl: './not-authorized.component.html',
  styleUrls: ['./../app.component.css','./not-authorized.component.css']
})
export class NotAuthorizedComponent implements OnInit {
  path: string;
  constructor(private route: Router) { }

  ngOnInit() {
    
  }

}
