import { Component, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from './../auth/auth.service';
declare var $: any;

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.css']
})
export class ProductManagementComponent implements OnInit {
  @HostListener('click', ['$event'])
  clickInside(event) {
    if(event.target.className.indexOf('current-sel-opt') == -1) this.isBUListShow = this.isReqTypeListShow = false;    
  }

  managementType: string = "";
  currentProductItem: string = "";
  articles: any[] = [];
  productRequestForm:any='';
  currentBusinessUnit: string = "";
  error:any = '';
  success:any = '';
  checkValue:boolean=true;
   
  private resetErrors(){
    this.success = '';
    this.error   = '';
  }

  managementListItem: any = [
    {
      name: "SELFMANAGED",
      selected: false,
      disabled: false,
    },
    {
      name: "TOOLMANAGED",
      selected: false,
      disabled: false,
    }
  ];

  isBUListShow: boolean = false;
  isReqTypeListShow:boolean = false;


  constructor(
    private fb: FormBuilder,
    private getService:sharedService,
    private router: Router,
    private authService:AuthService
  ) { }

  ngOnInit() {
    this.getBusinessUnit();
    this.productRequestForm = this.fb.group({
      'businessUnit':[null,[Validators.required]],
      'productLineName': ['', [Validators.required,Validators.pattern(/^[a-zA-Z0-9 ]+$/)]],
      'requestType':[null,[Validators.required]],
      'oui': ['',[Validators.pattern(/^[a-zA-Z0-9:]+$/)]],
      'quota': ['0',[Validators.max(50000)]],
      'requestedBy':this.authService.userName
    });
    
  }

  checkNullvalue(){
    if(this.productRequestForm.value.quota==null){
      this.productRequestForm.controls['quota'].patchValue('0');
      this.productRequestForm.controls['requestedBy'].patchValue(this.authService.userName);
    }
    else{
      this.productRequestForm.controls['requestedBy'].patchValue(this.authService.userName);
    }
  }

  get f() {
    return this.productRequestForm.controls;
  }
  filterForeCasts(args) {
    // this.productRequestForm.value.oui.patchValue(args.target.value, {
    //   onlySelf: true
    // })
    this.productRequestForm.value.businessUnit = args.target.value;
    // if(args.target.value ==0 ){
    // this.productRequestForm.value.oui = args.target.value;
    // }else{
    // // this.productRequestForm.value.oui = args.target.value; 
    // this.productRequestForm.value.oui = args.target.options[args.target.selectedIndex].text; 
    // }
    console.log(this.productRequestForm.value.businessUnit);
  }
  filterForeCasts2(args) {
    // this.productRequestForm.value.requestType.patchValue(args.target.value, {
    //   onlySelf: true
    // })
     this.productRequestForm.value.requestType = args.target.value;
    // if(args.target.value ==0 ){
    // this.productRequestForm.value.oui = args.target.value;
    // }else{
    // // this.productRequestForm.value.oui = args.target.value; 
    // this.productRequestForm.value.oui = args.target.options[args.target.selectedIndex].text; 
    // }
    console.log(this.productRequestForm.value.requestType);
  }

  getBusinessUnit(): void {
    this.checkValue=false;
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {

        res.forEach( item => {
          this.checkValue=true;
          console.log(item.businessUnit);
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
        })
        console.log(this.articles);
      },
      (err) => {
        this.articles = err;
      });
  }

  toggleDropDownList(type) {
    console.log(type)
    if (type == 'BU') {
      this.isBUListShow = !this.isBUListShow;
      this.isReqTypeListShow = false;
    }else if (type == 'ReqType') {
      this.isReqTypeListShow = !this.isReqTypeListShow;
      this.isBUListShow = false;
    }
  }


  dropdownOptionSelector(event, index, arr, list, selectItem) {
    event.stopPropagation();
    console.log(event, index, arr, list, selectItem)
    console.log(arr, this[arr])
    this[arr].forEach((i, v) => {
      i.selected = false;
      if (v == index) {
        i.selected = true;
        this.productRequestForm[selectItem] = i.name;
        this.managementType = this.productRequestForm[selectItem];
        if(selectItem == 'buName'){
          this.productRequestForm.controls['businessUnit'].setValue( i.name);
        }
        if(selectItem == 'requestType'){
          this.productRequestForm.controls['requestType'].setValue( i.name);
        }
      }
    });

    this[list] = false;

    //this.setClientOption();
  }



  
  
  
  submitProductData() {
    this.resetErrors();
    this.checkNullvalue();
    this.checkValue=false;
      let data = this.productRequestForm.value;
      this.getService.createProductLine(data).subscribe(res => { 
        let output = res.body.data;
       
      },
      (err) => {
        console.log(err);
        if(err.status==200){
          this.success = err.error.text;
          this.openModel("#toolMgmtModel");
          this.checkValue=true;
          this.productRequestForm.reset();
          // this.getBusinessUnit();
          // setTimeout(()=>{    //<<<---    using ()=> syntax
          //   this.closeModel('#toolMgmtModel');
          // }, 4000);
        }else if(err.status==400 || err.status==406 || err.status==500){
          this.error = err.error.message;
          this.openModel("#errorModel");
          this.checkValue=true;
        }else {
          this.error = "Internal Server Error";
          this.openModel("#errorModel");
          this.checkValue=true;
        }

      }

      ); 

  }

  openModel(modalName) {
    $(modalName).modal('show');
    console.log('updated')
  }
  closeModel(modalName) {
     $(modalName).modal('hide');
  }
  

}
