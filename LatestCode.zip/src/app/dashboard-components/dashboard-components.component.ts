import { Component, OnInit } from '@angular/core';
import { AuthService } from './../auth/auth.service';
import { Router } from '@angular/router';
import { sharedService } from './../service/shared-service.service';

declare var $: any;

@Component({
  selector: 'app-dashboard-components',
  templateUrl: './dashboard-components.component.html',
  styleUrls: ['./dashboard-components.component.css',],
})
export class DashboardComponentsComponent implements OnInit {


  constructor(
    public getService:sharedService,
    private router: Router,
    public AuthService:AuthService

  ) {
  
   }


  ngOnInit() {
    // if(this.getService.navigatepage==true){
    //   window.location.href="http://www.google.com";
    // }else{
    //   this.router.navigate(['mac/dashboard']);
    // }

    let temporaryThis = this; 

    
    if(this.getService.popOpenCount ==1){
      this.getService.popOpenFlag=true;
      
    }
    
    if(this.getService.popOpenFlag==false){
      this.getService.popOpenCount =1;
      // temporaryThis.closeModel('#errorModel');
    }

    // if(this.getService.pageCount == 0){
    //   temporaryThis.openModel('#errorModel');
    //   this.getService.pageCount =1;
    // }

     
   

  }

 
  openModel(modalName) {
    $(modalName).modal('show');
    console.log('updated')
  }
  closeModel(modalName) {
     $(modalName).modal('hide');
  }

  // navigatepage(){
  //   this.closeModel('#errorModel');
  //   this.router.navigate(['mac/faq']); 
  // }
  // resetform(){
  //   this.closeModel('#errorModel');
  // }

  
}
