import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-oui-pop-up',
  templateUrl: './oui-pop-up.component.html',
  styleUrls: ['./../app.component.css', '../dashboard/dashboard.component.css','./../generate-mac/generate-mac.component.css','./oui-pop-up.component.css'],
 // providers: [NgbModalConfig, NgbModal]
})
export class OuiPopUpComponent implements OnInit {

  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      requestType:"",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  selectedItem:any = "";


  requestedClientNames:any = [
    {
      clientName: "Test Client",
      requestDate:"6-Oct-2019",
      raisedBy: "H91212",
      requestStatus:"Pending",
      productLine: "Ent"
    },
    {
      clientName: "HON Client",
      requestDate:"6-Oct-2019",
      raisedBy: "H55250",
      requestStatus:"Approved",
      productLine: "Ent"
    },
    {
      clientName: "HBT Security Client",
      requestDate:"6-Oct-2019",
      raisedBy: "H90230",
      requestStatus:"Approved",
      productLine: "Ent"
    },
    {
      clientName: "Test ENV",
      requestDate:"6-Oct-2019",
      raisedBy: "H32632",
      requestStatus:"Rejected",
      productLine: "Ent"
    },
    {
      clientName: "HBT Dev",
      requestDate:"6-Oct-2019",
      raisedBy: "H12334",
      requestStatus:"Pending",
      productLine: "Ent"
    },
    {
      clientName: "Hon Client 3",
      requestDate:"6-Oct-2019",
      raisedBy: "H764833",
      requestStatus:"Rejected",
      productLine: "Ent"
    },
  ]

  popupProductLineData:any = [
    {
      name: "Ent",
      selected: false,
      disabled: false
    },
    {
      name: "Rob",
      selected: false,
      disabled: false
    },
    {
      name: "Rav",
      selected: false,
      disabled: false
    }
  ]


  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    
    ){

      
     }

  ngOnInit() {

  }

  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }

  publishData() {
    console.log("Published..!");
  }

  editRecord(item) {
    console.log("item=>", item);
    for(let ind=0;ind<this.popupProductLineData.length;ind++) {
      if(this.popupProductLineData[ind].name == item.productLine) {
        this.popupProductLineData[ind].selected = true;
        this.popupSelectedOption.productLine.mainValue = item.productLine;
        this.popupSelectedOption.productLine.clientName = item.clientName;
      } else {
        this.popupProductLineData[ind].selected = false;
      }

      console.log( this.popupSelectedOption.productLine)
    }

    this.selectedItem = item;
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    console.log(event,index,arr,selection,showVar,unitName);
    console.log(this[arr])
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
  }

  saveClientName() {
    console.log(this.popupSelectedOption.productLine)
    for(let ind = 0; ind < this.requestedClientNames.length; ind++) {
        if(this.requestedClientNames[ind].clientName == this.selectedItem.clientName) {
          this.requestedClientNames[ind].productLine = this.popupSelectedOption.productLine.mainValue;
          this.requestedClientNames[ind].clientName = this.popupSelectedOption.productLine.clientName;
          break;
        }
    }
    this.productclosebutton.nativeElement.click();
  }






}
