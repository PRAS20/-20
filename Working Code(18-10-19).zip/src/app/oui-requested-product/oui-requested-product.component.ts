import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';

@Component({
  selector: 'app-oui-requested-product',
  templateUrl: './oui-requested-product.component.html',
  styleUrls: ['./../app.component.css', '../dashboard/dashboard.component.css','./../generate-mac/generate-mac.component.css','./oui-requested-product.component.css']
})
export class OuiRequestedProductComponent implements OnInit {

  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  selectedItem:any = "";


  requestedProductNames:any = [
    {
      productName: "Test 1",
      requestDate:"2-Oct-2019",
      raisedBy: "H528552",
      requestStatus:"Rejected",
      businessUnit: "HBT",
      macOUI: "OUI"
    },
    {
      productName: "Honeywell Test",
      requestDate:"11-Oct-2019",
      raisedBy: "H344552",
      requestStatus:"Approved",
      businessUnit: "HBT",
      macOUI: "OUI"
    },
    {
      productName: "HBT Test 3",
      requestDate:"5-Oct-2019",
      raisedBy: "H728555",
      requestStatus:"Pending",
      businessUnit: "HBT",
      macOUI: "OUI"
    },
    {
      productName: "Test 4",
      requestDate:"25-Oct-2019",
      raisedBy: "H528082",
      requestStatus:"Rejected",
      businessUnit: "HBT",
      macOUI: "OUI"
    },
    {
      productName: "Test Envio",
      requestDate:"9-Oct-2019",
      raisedBy: "H547532",
      requestStatus:"Pending",
      businessUnit: "HBT",
      macOUI: "OUI"
    },
    {
      productName: "HBT GLobal",
      requestDate:"9-Oct-2019",
      raisedBy: "H212552",
      requestStatus:"Pending",
      businessUnit: "HBT",
      macOUI: "OUI"
    },
    {
      productName: "Hon DEV",
      requestDate:"6-Oct-2019",
      raisedBy: "H773452",
      requestStatus:"Approved",
      businessUnit: "HBT",
      macOUI: "OUI"
    }
  ]

 
  popupBusinessLineData:any = [
    {
      name: "iPhone",
      selected: false,
      disabled: false
    },
    {
      name: "Android",
      selected: false,
      disabled: false
    },
    {
      name: "Windows",
      selected: false,
      disabled: false
    }
  ]


  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    
    ){

      
     }

  ngOnInit() {

  }

  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }

  publishData() {
    console.log("Published..!");
  }

  editRecord(item) {
    console.log("item=>", item);
    for(let ind=0;ind<this.popupBusinessLineData.length;ind++) {
      if(this.popupBusinessLineData[ind].name == item.businessUnit) {
        this.popupBusinessLineData[ind].selected = true;
        this.popupSelectedOption.businessUnit.mainValue = item.businessUnit;
        this.popupSelectedOption.businessUnit.prodName = item.productName;
        this.popupSelectedOption.businessUnit.macOUI = item.macOUI;
      } else {
        this.popupBusinessLineData[ind].selected = false;
      }
    }

    this.selectedItem = item;
    
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
  }

  sendProductName() {
    console.log(this.popupSelectedOption.businessUnit);

    for(let ind = 0; ind < this.requestedProductNames.length; ind++) {
        if(this.requestedProductNames[ind].productName == this.selectedItem.productName) {
          this.requestedProductNames[ind].businessUnit = this.popupSelectedOption.businessUnit.mainValue;
          this.requestedProductNames[ind].productName = this.popupSelectedOption.businessUnit.prodName;
          this.requestedProductNames[ind].macOUI = this.popupSelectedOption.businessUnit.macOUI;
          break;
        }
    }
    this.closebutton.nativeElement.click();
  }

}
