import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OuiPopUpComponent } from './oui-pop-up/oui-pop-up.component';
import { GenerateMacComponent } from './generate-mac/generate-mac.component';
import { OuiRequestedProductComponent } from './oui-requested-product/oui-requested-product.component';
import { ClientGeneratorComponent } from './client-generator/client-generator.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { NotAuthorizedComponent } from './not-authorized/not-authorized.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  {
    path:'',component:DashboardComponent
  },
  {
    path:'dashboard',component:DashboardComponent, children :[
      {
        path:'requested_client',component:OuiPopUpComponent, canActivate: [AuthGuard]
      },
       {
        path:'requested_product',component:OuiRequestedProductComponent, canActivate: [AuthGuard]
      }, 
      {
        //path:'generate_mac',component:GenerateMacComponent
        path:'generate_mac',component:GenerateMacComponent
      },
      {
        path:'client_generator',component:ClientGeneratorComponent
      },
      {
        path:'product_management',component:ProductManagementComponent
      },
      
    ],
    canActivateChild: [AuthGuard]
    
   },
   {
      path: 'not_authorized',component:NotAuthorizedComponent
    }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
