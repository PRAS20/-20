import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap, delay } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn:boolean = true;
  isAdmin:boolean = false;

  constructor(
    private router:Router
  ) { }

  login(): Observable<boolean> {
    return of(true).pipe(
      delay(1000),
      tap(val => this.isLoggedIn = true)
    );
  }

  logout(): void {
    console.log('logout')
    this.isLoggedIn = false;
    console.log('logout',this.isLoggedIn);
    this.router.navigate(['dashboard']);
    sessionStorage.clear()
  }
}
