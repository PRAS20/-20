import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-client-generator',
  templateUrl: './client-generator.component.html',
  styleUrls: ['./../app.component.css','./client-generator.component.css']
})
export class ClientGeneratorComponent implements OnInit {

  selectedBusinessId:any="null";
  selectedBusinessobj:any= "null";
  selectedProjectId:any="null";
  selectedProjectobj:any= "null";
  articles: string[];
  ouiList: string [];
  productList:string [];
  getMacListDetails:string [];
  createBusiness: FormGroup;
  createProduct:FormGroup;
  generateMac:FormGroup;
  clientNamePop:boolean = false;
  productNamePop:boolean = false;
  selectedClientOption:string = "";
  selectedProductOption:string = "";
  showDetails=false;
  profileForm = this.fb.group({
    serialNumber: ['',Validators.required],
    deviceDate: ['',Validators.required],
    batchCode: ['',Validators.required],
    otherDetails: ['',Validators.required],
    noOfmacIds: ['',Validators.required],
  });

  clientNames = [
    {
      name: "Test Client  1",
      selected: false,
      disabled: false
    },
    {
      name: "HBT Client",
      selected: true,
      disabled: false
    },
  ];

  productNames = [
    {
      name: "Arizona Strip Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Grand Canyon Prod",
      selected: true,
      disabled: false
    },
    {
      name: "North Central Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Northeast Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Northern Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Disabled Option Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Phoenix Metropolitan Prod",
      selected: false,
      disabled: true
    },
    {
      name: "Southern Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Direction One Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Direction Two Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Direction Three Prod",
      selected: false,
      disabled: false
    },
    {
      name: "Direction Four Prod",
      selected: false,
      disabled: false
    }
  ];

  popupBusinessLineData:any = [
    {
      name: "App",
      selected: false,
      disabled: false
    },
    {
      name: "Ball",
      selected: false,
      disabled: false
    },
    {
      name: "Sket",
      selected: false,
      disabled: false
    }
  ]

  popupProductLineData:any = [
    {
      name: "Ent",
      selected: false,
      disabled: false
    },
    {
      name: "Rob",
      selected: false,
      disabled: false
    },
    {
      name: "Rav",
      selected: false,
      disabled: false
    }
  ]

  public addDetails = false;

  businessUnits:any = [
    {
    id:"1",
    name:'Honeywell Security'
    },
    {
      id:"2",
      name:'Alerton'
    },
    {
      id:"3",
      name:'Honeywell ACS'
    },
  ]

  productLines:any = [
    {
    id:"1",
    name:'ALERTON TECHNOLOGIES, INC'
    },
    {
      id:"2",
      name:'Honeywell Connected Building'
    },
    {
      id:"3",
      name:'Honeywell International HPS'
    },
  ]



  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient
    ){

      this.setClientOption()
      this.setProductOption()
     }

  ngOnInit() {
    this.generateMac = this.fb.group({
      'businessUnit':[null, [ Validators.required ] ],
      'productLine':[null, [ Validators.required ] ],
      'serialName':[null, [ Validators.required ] ],
      'deviceDate':[null, [ Validators.required ] ],
      'batchCode':[null, [ Validators.required ] ],
      'otherDetails':[null],
      'numberOfMAC':[null, [ Validators.required ]]
    });

    this.createBusiness = this.fb.group({
      'businessUnitName':[null, [ Validators.required ] ],
      'ouiName':[null, [ Validators.required ] ]
    });

    this.createProduct = this.fb.group({
      'businessUnit_PL':[null, [ Validators.required ] ],
      'productLineName':[null, [ Validators.required ] ],
      'oui_PL':[null, [ Validators.required ] ],
      'quotaName':[null, [ Validators.required ] ]
    });

    this.getData();
    this.getOUIs();
    this.getProductList();

  }

  toggleClientPop() {
    this.productNamePop = false;
    this.clientNamePop = !this.clientNamePop;
    this.showDetails =true;
  }

  toggleProductPop() {
    this.clientNamePop = false;
    this.productNamePop = !this.productNamePop;
  }

  clientOptionSelector(event,index) {
    event.stopPropagation();
    this.clientNames.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedClientOption = i.name;
      }
    });
    this.clientNamePop = false;
    //this.setClientOption();
  }

  productOptionSelector(event,index) {
    event.stopPropagation();
    this.productNames.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedProductOption = i.name;
      }
    });
    this.productNamePop = false;
    //this.setClientOption();
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    console.log(event,index,arr,selection,showVar,unitName);
    console.log(this[arr])
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
  }

  setClientOption() {
    console.log('seett');
    for(let ind = 0; ind<this.clientNames.length;ind++) {
      if(this.clientNames[ind].selected) {
        this.selectedClientOption = this.clientNames[ind].name;
        break;
      }
    }
  }

  setProductOption() {
    console.log('seett  1');
    for(let ind = 0; ind<this.productNames.length;ind++) {
      if(this.productNames[ind].selected) {
        this.selectedProductOption = this.productNames[ind].name;
        break;
      }
    }
  }

  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }

  sendBusinessData(objName){
    console.log("Business Data",this.popupSelectedOption[objName]);
    var bool:boolean = false;
    let receivedValue:any = this.popupSelectedOption[objName];
    for(let i=0;i<this.productNames.length;i++) {
        if(this.productNames[i].name == receivedValue.mainValue) {
          bool = true;
          break;
        }
    }
    if(!bool) {
      this.productNames.push({
        'name': receivedValue.mainValue,
        'selected': false,
        'disabled': false
      });
    }

    //$("#myModal").modal('hide');
    this.closebutton.nativeElement.click();
  }
  
  sendProductLineData(objName:any){
    console.log("Product Data",this.popupSelectedOption[objName]);
    var bool:boolean = false;
    let receivedValue:any = this.popupSelectedOption[objName];
    for(let i=0;i<this.clientNames.length;i++) {
        if(this.clientNames[i].name == receivedValue.mainValue) {
          bool = true;
          break;
        }
    }
    if(!bool) {
      this.clientNames.push({
        'name': receivedValue.mainValue,
        'selected': false,
        'disabled': false
      });
    }

    //$("#myModal").modal('hide');
    this.productclosebutton.nativeElement.click();
  }

  

  getData() {
    this.http.get('http://10.219.42.66/getData.php').subscribe((data) => {
      console.log(data);
      this.articles = data as string[];
      console.log(this.articles);
    });
  }

  getOUIs() {
    this.http.get('http://localhost:54512/macid/getouis').subscribe((data) => {
      console.log(data);
      this.ouiList = data as string[];
      console.log(this.ouiList);
    });
  }
  getProductList() {
    this.http.get('http://10.219.42.66/getPLData.php').subscribe((data) => {
      console.log(data);
      this.productList = data as string[];
      console.log(this.productList);
    });
  }

  
  

  createBusinessDetails() {
    let BD = this.createBusiness.value;
  
    // let addOUI = "http://localhost:54512/macid/addoui?ouiname=" + x.ouiname + "&quota=" + x.quota
     let createBU = "http://10.219.42.66/createBusiness.php"
    this.http.post(createBU,this.createBusiness.value)
      .subscribe((response) => {
        this.getData();
        console.log('response', response);
      })
    this.modalService.dismissAll();
    this.createBusiness.reset();
  }

  createProductLineDetails(){
    let PLD = this.createProduct.value;
    console.log(PLD)
    let createPL = "http://10.219.42.66/createProductLine.php"
    this.http.post(createPL,this.createProduct.value)
      .subscribe((response) => {
        this.getProductList();
        console.log('response', response);
      })
    this.modalService.dismissAll();
    this.createProduct.reset();
  }

  onSubmitdata() {
    let generateMACValue = this.generateMac.value;
    console.log(generateMACValue);
    let generateMac = "http://10.219.42.66/getMacList.php"
    this.http.post(generateMac,this.generateMac.value)
      .subscribe((response) => {
        console.log('response', response);
        this.getMacListDetails = response as string[];
        console.log(this.getMacListDetails);
      })

  }

  changeValueBusiness(a){
    this.selectedBusinessId = a.target.value;
    for(let x=0;x<this.businessUnits.length;x++){
         if(this.businessUnits[x]['id']==this.selectedBusinessId){
           this.selectedBusinessobj = this.businessUnits[x];
         }
    }
    if(this.selectedBusinessId =='null'){
     this.selectedBusinessobj="null";
     
    } 
  }//End of change value for Business Unit

  changeValue(b){
     this.selectedProjectId = b.target.value;
     for(let x=0;x<this.productLines.length;x++){
          if(this.productLines[x]['id']==this.selectedProjectId){
            this.selectedProjectobj = this.productLines[x];
          }
     }
     if(this.selectedProjectId =='null'){
      this.selectedProjectobj="null"; 
     } 
     this.showtext();
  }//End of change value for Product Line
  
  public  showtext(){
    if(this.selectedBusinessId !='null' && this.selectedProjectId !='null'){
      this.addDetails = true;
    }
  }

  open_add_BU(add_BU) {
    this.modalService.open(add_BU);
  }
  
  open_add_PL(add_PL) {
    this.modalService.open(add_PL);
  }

  open_mac_Popup(getMacPopUp){
    this.modalService.open(getMacPopUp);
  }

  formChanging() {
    console.log(this.profileForm);
  }

  submitSerialNoDatas() {
    console.log(this.profileForm);
  }

}
