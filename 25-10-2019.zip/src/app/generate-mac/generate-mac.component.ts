import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ExportMacInCsvService } from './../service/export-mac-in-csv.service';
import { sharedService } from './../service/shared-service.service';


@Component({
  selector: 'app-generate-mac',
  templateUrl: './generate-mac.component.html',
  styleUrls: ['./../app.component.css', './generate-mac.component.css']
})
export class GenerateMacComponent implements OnInit {

  currentBusinessUnit: string = "";
  newCurrentBusinessUnit: string = "";
  currentProductItem: string = "";
  managementType: string = "";
  chooseManagementType: string = "";
  articles: any[] = [];
  productDetails: any[] = [];




  managementListItem: any = [
    {
    name: "Self Managed",
    selected: false,
    disabled: false,
  },
  {
    name: "Tool Managed",
    selected: false,
    disabled: false,
  }
];


  popupControls: any = {
    popupForProductionList: false,
  }

  popupSelectedOption: any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
  }

  jsonData =  [
    {
      name: "Honeywell",
      mac_address: '22:33:44cf:76aq'
    },
    {
      name: 'Honeywell',
      mac_address: '28:43:46ls:54ed'
    },
    {
      name: 'Honeywell',
      mac_address: '68:17:94zh:02jx'
    },
  ];

  buList: boolean = false;
  buListforNewProduct: boolean = false;
  prodList: boolean = false;
  managementList: boolean = false;
  showDetails: boolean = false;

  @HostListener('click', ['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
    if(event.target.className.indexOf('current-sel-opt') == -1) this.buList = this.prodList = this.managementList = this.popupControls.popupForProductionList = false;    
  }

  @ViewChild('closebutton', { static: false }) closebutton;
  @ViewChild('closebuttonMac', { static: false }) closebuttonMac;
  
  @ViewChild('productlineclosebutton', { static: false }) productclosebutton;
  
  generateMac: any = "";
  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient,
    private exportService: ExportMacInCsvService,
    private getService:sharedService
  ) {


  }

  ngOnInit() {
    this.getBusinessUnit();
    this.getProductDetails();
  }
  allRequests=[];
  articlesdata: any[] =[];
  getBusinessUnit(): void {
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
         this.articlesdata = item.businessUnit;
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
          // console.log(this.allRequests=res);
        })
       
        console.log(this.articlesdata);
       
      },
      (err) => {
        this.articles = err;
      });
  }


  getProductDetails(): void {
    let BussinessUnitList =  this.articlesdata;
    this.getService.getProductDetails_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
          console.log(item.productLineName);
          this.productDetails.push({
            name: item.productLineName,
            selected: false,
            disabled: false,
            type:item.requestType,
            businessUnit:item.businessUnit
          })
        })
        console.log(res[0].businessUnit);
      },
      (err) => {
        this.productDetails = err;
      });
  }



  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool: boolean = false;
    for (var key in this.popupSelectedOption[objName]) {
      if (this.popupSelectedOption[objName].hasOwnProperty(key)) {
        if (this.popupSelectedOption[objName][key] == null || this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined) {
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }
  downloadCSV(){
    this.exportService.downloadFile(this.jsonData, 'jsontocsv');
  }
  toggleDropDownList(type) {
    if (type == 'BU') {
      this.buList = !this.buList;
      this.prodList = false;
    }else if (type == 'NPL') {
      this.buListforNewProduct = !this.buListforNewProduct;
      this.prodList = false;
    }else if(type== 'PL'){
      this.prodList = !this.prodList;
      this.buList = false;
      this.buListforNewProduct =false;
    } else if(type == 'CreateProduct') {
      this.popupControls.popupForProductionList = !this.popupControls.popupForProductionList;
    } else if(type == 'MT') {
      this.managementList = !this.managementList;
    }
  }

  dropdownOptionSelector(event, index, arr, list, selectItem) {
    event.stopPropagation();
    console.log(event, index, arr, list, selectItem)
    console.log(arr, this[arr])
    this[arr].forEach((i, v) => {
      i.selected = false;
      if (v == index) {
        i.selected = true;
        this[selectItem] = i.name;
        if (selectItem == 'currentProductItem') {
          this.managementType = i.type;
        } else if (selectItem == 'currentBusinessUnit') {
          this.currentProductItem = "";
          this.managementType = "";
        }else if (selectItem == 'newCurrentBusinessUnit') {
          this.currentProductItem = "";
          this.managementType = "";
        }
      }
    });

    this[list] = false;

    //this.setClientOption();
  }

  openProductCreation() {
    this.popupSelectedOption.businessUnit.mainValue = this.currentBusinessUnit;
    this.popupSelectedOption.businessUnit.mainValue = this.newCurrentBusinessUnit;
  }

  openGenerateMAC(){

  }

  sendBusinessData() {
    console.log("Data to Send",this.popupSelectedOption.businessUnit);
    this.closebutton.nativeElement.click();
    this.closebuttonMac.nativeElement.click();
    
  }



  copyMacAddress() {
    var copyText = document.getElementsByClassName("mac-address")[0];
    var textArea = document.createElement("textarea");
    textArea.value = copyText.textContent;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand("Copy");
    textArea.remove();
  }

}

