import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';

@Component({
  selector: 'app-oui-statistics',
  templateUrl: './oui-statistics.component.html',
  styleUrls: ['./oui-statistics.component.css']
})
export class OuiStatisticsComponent implements OnInit {

  ouiDetails: any[] = [];

  constructor(private getService:sharedService) { }

  ngOnInit() {
    this.getOUIDetails();
  }

  getOUIDetails(): void {
    this.getService.getOUIDetails_api().subscribe(
      (res: any[]) => {
        this.ouiDetails = res;
        console.log(this.ouiDetails);
      },
      (err) => {
        this.ouiDetails = err;
      });
  }

}
