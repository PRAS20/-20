import { TestBed } from '@angular/core/testing';

import { ExportMacInCsvService } from './export-mac-in-csv.service';

describe('ExportMacInCsvService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ExportMacInCsvService = TestBed.get(ExportMacInCsvService);
    expect(service).toBeTruthy();
  });
});
