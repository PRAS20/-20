import { Component, OnInit } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-generate-mac',
  templateUrl: './generate-mac.component.html',
  styleUrls: ['./../app.component.css','../dashboard/dashboard.component.css']
})
export class GenerateMacComponent implements OnInit {

  constructor(private modalService: NgbModal,private fb: FormBuilder) { }
  countryForm: FormGroup;
  ngOnInit() {
    this.countryForm = this.fb.group({
      countryControl: []
    });
  }
  
  open_add_BU(add_BU) {
    this.modalService.open(add_BU);
  }
  
  open_add_PL(add_PL) {
    this.modalService.open(add_PL);
  }

}
