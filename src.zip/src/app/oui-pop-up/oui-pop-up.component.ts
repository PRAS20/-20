import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-oui-pop-up',
  templateUrl: './oui-pop-up.component.html',
  styleUrls: ['./../app.component.css','../dashboard/dashboard.component.css'],
  providers: [NgbModalConfig, NgbModal]
})
export class OuiPopUpComponent implements OnInit {

  constructor(private modalService: NgbModal,private fb: FormBuilder) { }
  countryForm: FormGroup;
  countries = [
    {
      id: '00000',
      name: 'Select any OUI',
      code: '00'
    },
    {
    
    id: '8f8c6e98',
    name: 'USA',
    code: 'USD'
   },
   {
    id: '169fee1a',
    name: 'Canada',
    code: 'CAD'
   },
   {
    id: '3953154c',
    name: 'UK',
    code: 'GBP'
   }]

   addNewOption(name: string, code: string) {
    setTimeout(() => {
     this.countries = [
        {
          id: '00000',
          name: 'select any OUI',
          code: '00'
        },
        {
          id: '8f8c6e98',
          name: 'USA',
          code: 'USD'
        },
        {  
          id: '169fee1a',
          name: 'Canada',
          code: 'CAD'
        },
        {
          id: '3953154c',
          name: 'UK',
          code: 'GBP'
        },
        {
          id: '68c61e29',
          name,
          code:'SP'
        }
    ];
  this.countryForm.controls['countryControl'].patchValue(
       {id : '68c61e29', name, code:'SP'}
    )
   }, 500)
  }
  countryValue;
  selectchange(args){ 
    this.countryValue = args.target.options[args.target.selectedIndex].text; 
    console.log(args.target.options[args.target.selectedIndex])
  } 
  ngOnInit() {
   this.countryForm = this.fb.group({
      countryControl: [this.countries[0]]
    });
  }
  open(content) {
    this.modalService.open(content);
  }

  

}
