import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class sharedService {
    baseUrl = 'http://www.json-generator.com/api/json/get/bTNBAgQsKq?indent=2';
    articles1: any[] = [];
    constructor(private http: HttpClient) { }
    
  
      getData(): Observable<any> {
        return this.http.get('http://www.json-generator.com/api/json/get/bTNBAgQsKq?indent=2').pipe(
          map((res: any[]) => {
            this.articles1 = res;
            return this.articles1;
        }),
        );
      }

    
}