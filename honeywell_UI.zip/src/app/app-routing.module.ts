import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OuiPopUpComponent } from './oui-pop-up/oui-pop-up.component';
//import { GenerateMacComponent } from './generate-mac/generate-mac.component';

const routes: Routes = [
  {
    path:'',component:LoginComponent
  },
  {
    path:'login',component:LoginComponent
  },
  {
    path:'dashboard',component:DashboardComponent, children :[
      {
        path:'oui',component:OuiPopUpComponent
      },
      {
        //path:'generate_mac',component:GenerateMacComponent
        path:'generate_mac',component:OuiPopUpComponent
      }
    ] },
 
  {
    path:'logout',component:LoginComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
