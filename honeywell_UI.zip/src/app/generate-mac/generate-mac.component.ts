import { Component, OnInit } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-generate-mac',
  templateUrl: './generate-mac.component.html',
  styleUrls: ['./../app.component.css','../dashboard/dashboard.component.css']
})
export class GenerateMacComponent implements OnInit {
  
  selectedBusinessId:any="null";
  selectedBusinessobj:any= "null";
  selectedProjectId:any="null";
  selectedProjectobj:any= "null";
  articles: string[];
  ouiList: string [];
  productList:string [];
  getMacListDetails:string [];
  createBusiness: FormGroup;
  createProduct:FormGroup;
  generateMac:FormGroup;
  public addDetails = false;

  businessUnits:any = [
    {
    id:"1",
    name:'Honeywell Security'
    },
    {
      id:"2",
      name:'Alerton'
    },
    {
      id:"3",
      name:'Honeywell ACS'
    },
  ]

  productLines:any = [
    {
    id:"1",
    name:'ALERTON TECHNOLOGIES, INC'
    },
    {
      id:"2",
      name:'Honeywell Connected Building'
    },
    {
      id:"3",
      name:'Honeywell International HPS'
    },
  ]

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient
    ){ }

  ngOnInit() {
    this.generateMac = this.fb.group({
      'businessUnit':[null, [ Validators.required ] ],
      'productLine':[null, [ Validators.required ] ],
      'serialName':[null, [ Validators.required ] ],
      'deviceDate':[null, [ Validators.required ] ],
      'batchCode':[null, [ Validators.required ] ],
      'otherDetails':[null],
      'numberOfMAC':[null, [ Validators.required ]]
    });

    this.createBusiness = this.fb.group({
      'businessUnitName':[null, [ Validators.required ] ],
      'ouiName':[null, [ Validators.required ] ]
    });

    this.createProduct = this.fb.group({
      'businessUnit_PL':[null, [ Validators.required ] ],
      'productLineName':[null, [ Validators.required ] ],
      'oui_PL':[null, [ Validators.required ] ],
      'quotaName':[null, [ Validators.required ] ]
    });

    this.getData();
    this.getOUIs();
    this.getProductList();

  }
  getData() {
    this.http.get('http://10.219.42.66/getData.php').subscribe((data) => {
      console.log(data);
      this.articles = data as string[];
      console.log(this.articles);
    });
  }

  getOUIs() {
    this.http.get('http://localhost:54512/macid/getouis').subscribe((data) => {
      console.log(data);
      this.ouiList = data as string[];
      console.log(this.ouiList);
    });
  }
  getProductList() {
    this.http.get('http://10.219.42.66/getPLData.php').subscribe((data) => {
      console.log(data);
      this.productList = data as string[];
      console.log(this.productList);
    });
  }

  
  

  createBusinessDetails() {
    let BD = this.createBusiness.value;
  
    // let addOUI = "http://localhost:54512/macid/addoui?ouiname=" + x.ouiname + "&quota=" + x.quota
     let createBU = "http://10.219.42.66/createBusiness.php"
    this.http.post(createBU,this.createBusiness.value)
      .subscribe((response) => {
        this.getData();
        console.log('response', response);
      })
    this.modalService.dismissAll();
    this.createBusiness.reset();
  }

  createProductLineDetails(){
    let PLD = this.createProduct.value;
    console.log(PLD)
    let createPL = "http://10.219.42.66/createProductLine.php"
    this.http.post(createPL,this.createProduct.value)
      .subscribe((response) => {
        this.getProductList();
        console.log('response', response);
      })
    this.modalService.dismissAll();
    this.createProduct.reset();
  }

  onSubmitdata() {
    let generateMACValue = this.generateMac.value;
    console.log(generateMACValue);
    let generateMac = "http://10.219.42.66/getMacList.php"
    this.http.post(generateMac,this.generateMac.value)
      .subscribe((response) => {
        console.log('response', response);
        this.getMacListDetails = response as string[];
        console.log(this.getMacListDetails);
      })

  }

  changeValueBusiness(a){
    this.selectedBusinessId = a.target.value;
    for(let x=0;x<this.businessUnits.length;x++){
         if(this.businessUnits[x]['id']==this.selectedBusinessId){
           this.selectedBusinessobj = this.businessUnits[x];
         }
    }
    if(this.selectedBusinessId =='null'){
     this.selectedBusinessobj="null";
     
    } 
  }//End of change value for Business Unit

  changeValue(b){
     this.selectedProjectId = b.target.value;
     for(let x=0;x<this.productLines.length;x++){
          if(this.productLines[x]['id']==this.selectedProjectId){
            this.selectedProjectobj = this.productLines[x];
          }
     }
     if(this.selectedProjectId =='null'){
      this.selectedProjectobj="null"; 
     } 
     this.showtext();
  }//End of change value for Product Line
  
  public  showtext(){
    if(this.selectedBusinessId !='null' && this.selectedProjectId !='null'){
      this.addDetails = true;
    }
  }

  open_add_BU(add_BU) {
    this.modalService.open(add_BU);
  }
  
  open_add_PL(add_PL) {
    this.modalService.open(add_PL);
  }

  open_mac_Popup(getMacPopUp){
    this.modalService.open(getMacPopUp);
  }

}

