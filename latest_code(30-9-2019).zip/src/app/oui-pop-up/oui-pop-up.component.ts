import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';


@Component({
  selector: 'app-oui-pop-up',
  templateUrl: './oui-pop-up.component.html',
  styleUrls: ['./../app.component.css', '../dashboard/dashboard.component.css'],
  providers: [NgbModalConfig, NgbModal]
})
export class OuiPopUpComponent implements OnInit {

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }
  countryForm: FormGroup;
  ouiDetails: FormGroup;
  selectedOuiId: any = "null";
  selectedOuiObj: any = "null";
  articles: string[];
  ouiname: any;
  quota: number;
  ouis: any = [
    {
      id: 1,
      name: '00:60:2D',
      quota: '16000000000',
      macIdStart: '00:60:2D:00:00:00',
      macIdEnd: '00:60:2D:FF:FF:FF',
      macIdLeft: '2600000',
    },
    {
      id: 2,
      name: 'F0:54:94',
      quota: '8000000000',
      macIdStart: 'F0:54:94:00:00:00',
      macIdEnd: 'FF:54:FF:FF:FF:FF',
      macIdLeft: '15000000',
    },
    {
      id: 3,
      name: '00:40:84',
      quota: '200000000',
      macIdStart: '00:40:84:00:00:00 ',
      macIdEnd: '00:40:84:FF:FF:FF',
      macIdLeft: '10000000',
    }, {
      id: 4,
      name: '00:2A:DB',
      quota: '18000000',
      macIdStart: '00:2A:DB:00:00:00',
      macIdEnd: '00:2A:DB:00:BD:FF',
      macIdLeft: '34589528',
    },
  ]



  addNewOption(name: any, quota: any) {

    setTimeout(() => {
      this.ouis = [
        {
          id: 1,
          name: '00:60:2D',
          quota: '16000000000',
          macIdStart: '00:60:2D:00:00:00',
          macIdEnd: '00:60:2D:FF:FF:FF',
          macIdLeft: '2600000',
        }, {
          id: 2,
          name: 'F0:54:94',
          quota: '8000000000',
          macIdStart: 'F0:54:94:00:00:00',
          macIdEnd: 'FF:54:FF:FF:FF:FF',
          macIdLeft: '15000000',
        }, {
          id: 3,
          name: '00:40:84',
          quota: '200000000',
          macIdStart: '00:40:84:00:00:00 ',
          macIdEnd: '00:40:84:FF:FF:FF',
          macIdLeft: '10000000',
        }, {
          id: 4,
          name: '00:2A:DB',
          quota: '18000000',
          macIdStart: '00:2A:DB:00:00:00',
          macIdEnd: '00:2A:DB:00:BD:FF',
          macIdLeft: '34589528',
        }, {
          id: 5,
          name,
          quota,
          macIdStart: '00:2A:DB:00:00:00',
          macIdEnd: '00:2A:DB:00:BD:FF',
          macIdLeft: '160000000',
        },
      ];
      this.ouiDetails.controls['oui'].patchValue(
        { id: '68c61e29', name, quota, macIdStart: '00:2A:DB:00:00:00', macIdEnd: '00:2A:DB:00:BD:FF', macIdLeft: '160000000' }
      )
    }, 100)
    this.modalService.dismissAll();
  }

  selectchange(args) {
    this.selectedOuiId = args.target.value;
    for (let x = 0; x < this.articles.length; x++) {
      if (this.articles[x]['id'] == this.selectedOuiId) {
        this.selectedOuiObj = this.articles[x];
      }
    }
    if (this.selectedOuiId == 'null') {
      this.selectedOuiObj = "null";
    }
  } //End of change value for OUI's

  ngOnInit() {
    this.ouiDetails = this.fb.group({
      'ouiname': [null, [Validators.required]],
      'quota': [null, [Validators.required]],
    });
    this.getData();
  }
  getData() {
    this.http.get('http://localhost:54512/macid/getouis').subscribe((data) => {
      console.log(data);
      this.articles = data as string[];
      console.log(this.articles);
    });
  }
 
  onSubmitdata() {
    let x = this.ouiDetails.value;
    let addOUI = "http://localhost:54512/macid/addoui?ouiname=" + x.ouiname + "&quota=" + x.quota
    this.http.post(addOUI, { headers: { 'Access-Control-Allow-Origin': '*' } })
      .subscribe((response) => {
        this.getData();
        console.log('response', response);
      })
    this.modalService.dismissAll();
    this.ouiDetails.reset();
  }

  onDatavalue() {
    console.log(this.ouiDetails);
  }
  //Open Model Pop-up
  open(content) {
    this.modalService.open(content);
  }



}
