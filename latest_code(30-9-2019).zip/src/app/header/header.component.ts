import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./../app.component.css']
})
export class HeaderComponent implements OnInit {
  userName:string = "Prasanna";
  imgSrc:string = "./../assets/image/avatar.png";
  userOptions:boolean = true;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  onLoad(){
    this.router.navigate(['./logout']);
  }
  toggleUserOpt() {
    this.userOptions = !this.userOptions;
  }
}
