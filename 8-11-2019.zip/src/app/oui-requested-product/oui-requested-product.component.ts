import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { sharedService } from './../service/shared-service.service';
import {NgbModal,NgbActiveModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, Route,ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare var $: any;

@Component({
  selector: 'app-oui-requested-product',
  templateUrl: './oui-requested-product.component.html',
  styleUrls: ['./../app.component.css', '../dashboard/dashboard.component.css','./../generate-mac/generate-mac.component.css','./oui-requested-product.component.css']
})
export class OuiRequestedProductComponent implements OnInit {

  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      id:"",
      mainValue: "",
      prodName: "",
      macOUI: "",
      addressCount:"",
      requestType:""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  selectedItem:any = "";


  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
    if(event.target.className.indexOf('current-sel-opt') == -1) this.isBUListShow = this.isReqTypeListShow = false;   
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;
  myInp = "Ani";
  managementType: string = "";
  currentProductItem: string = "";
  articles: any[] = [];
  productRequestForm:any='';

  managementListItem: any = [
    {
      name: "Self Managed",
      selected: false,
      disabled: false,
    },
    {
      name: "Tool Managed",
      selected: false,
      disabled: false,
    }
  ];

  businessUnitList: any = [
    {
      name: "BU 1",
      selected: false,
      disabled: false
    },
    {
      name: "BU 2",
      selected: false,
      disabled: false
    },
    {
      name: "BU 3",
      selected: false,
      disabled: false
    },
    {
      name: "BU 4",
      selected: false,
      disabled: false
    },
    {
      name: "BU 5",
      selected: false,
      disabled: false
    },
    {
      name: "BU 6",
      selected: false,
      disabled: false
    }
  ]

  formData:any = {
    buName: {value:"",required:true},
    productName: {value:"",required:true},
    requestType: {value:"",required:true},
    macOUI: {value:"",required:false},
    addressCount: {value:"",required:false},
  };

  isBUListShow: boolean = false;
  isReqTypeListShow:boolean = false;
  

  constructor(
    private fb: FormBuilder,
    private getService:sharedService,
    private modalService: NgbModal,
    private _router: Router,
    ){ }

  ngOnInit() {
    this.getBusinessUnit();
    this.getProductRequestDetails();
    this.productRequestForm = this.fb.group({
      "id": [''],
      'businessUnit':[''],
      'productLineName': [null, [Validators.required,Validators.minLength(2)]],
      "requestType": [''],
      'oui': ['',[Validators.required]],
      'quota': ['',[Validators.required]],
    });
  }
  articlesdata: any[] =[];
  productRequestDetails: any[] = [];
  rejectRequestDetails: any[] = [];
  approveRequestDetails: any[] = [];
  error:any = '';
  success = '';
  private resetErrors(){
    this.success = '';
    this.error   = '';
  }

  get f() {
    return this.productRequestForm.controls;
  }

  getBusinessUnit(): void {
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
         this.articlesdata = item.businessUnit;
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
          // console.log(this.allRequests=res);
        })
        console.log(this.articlesdata);
      },
      (err) => {
        this.articles = err;
      });
  }

  getProductRequestDetails(): void {
    this.getService.getProductRequestDetails_api().subscribe(
      (res:  any[]) => {
        this.productRequestDetails = res;
      },
      (err) => {
        this.productRequestDetails = err;
      }
    );
  }

  confirmReject(){
    this.openModel("#rejectModel");
  }

  rejectRequestedProduct(rejectDetails){
    this.resetErrors();
    let rejectedRequestParam = {
      "id": rejectDetails.id,
      "status": "Rejected",
      "comments": "Not valid request"
    }
   console.log(rejectedRequestParam);
    // this.getService.updateProductRequest(rejectedRequestParam)
    //   .subscribe(
    //     (res) => {
    //       this.rejectRequestDetails    = res.body.data;  
    //     },
    //     (err) => {
    //       if(err.status==200){
    //         this.success = 'New Product Requested Successfully';
    //         this.getProductRequestDetails();
            
    //       }else{
    //         this.error = err.error.message;
    //         console.log(this.error)
    //       }
    //     }
    //   );
  }

  approveRequestedProduct(approvedDetails){
   
    let approvedRequestParam = {
      "id": approvedDetails.id,
      "businessUnit": approvedDetails.businessUnit,
      "productLineName": approvedDetails.productLineName,
      "requestType": approvedDetails.requestType,
      "oui": approvedDetails.oui,
      "quota": approvedDetails.quota,
      "status": "APPROVED",
      "comments": "Approved"
    }
    this.getService.updateExistingProduct(approvedRequestParam)
      .subscribe(
        (res) => {
          this.approveRequestDetails    = res.body.data;     
        },
        (err) => {
          console.log(err)
          if(err.status==200){
            this.success = 'New Product Requested Successfully';
            this.getProductRequestDetails();
            this.openModel("#approveModel");
          }else{
            this.error = err.error.message;
            console.log(this.error)
          }
        }
      );
  }
 
  
  updateProductDetails(updatedDetails) {
    
    let updatedRequestParam = {
      "id": updatedDetails.id,
      "businessUnit": updatedDetails.mainValue,
      "productLineName": this.productRequestForm.value.productLineName,
      "requestType": updatedDetails.requestType,
      "oui": this.productRequestForm.value.oui,
      "quota": this.productRequestForm.value.quota,
      "status":"EDIT",
      "comments": ""
    }
    this.getService.updateExistingProduct(updatedRequestParam)
      .subscribe(
        (res) => {
          this.approveRequestDetails    = res.body.data;    
        },
        (err) => {
          if(err.status==200){
            this.success = 'Product has been successfully updated';
            this.getProductRequestDetails();
            this.closeModel("#myModal");
            this.openModel("#updateModel");
          }
          else{
            this.error = err.error.message;
            this.getProductRequestDetails();
            console.log(this.error)
          }
        }
      );
  }

  toggleDropDownList(type) {
    console.log(type)
    if (type == 'BU') {
      this.isBUListShow = !this.isBUListShow;
      this.isReqTypeListShow = false;
    }else if (type == 'ReqType') {
      this.isReqTypeListShow = !this.isReqTypeListShow;
      this.isBUListShow = false;
    }
  }

  dropdownOptionSelector(event, index, arr, list, selectItem) {
    event.stopPropagation();
    console.log(event, index, arr, list, selectItem)
    console.log(arr, this[arr])
    this[arr].forEach((i, v) => {
      i.selected = false;
      if (v == index) {
        i.selected = true;
        this.formData[selectItem].value = i.name;
        this.managementType = this.formData[selectItem].value
        if(selectItem == 'requestType') {
          this.popupSelectedOption.businessUnit.requestType = i.name;
        } else if(selectItem == 'buName') {
          this.popupSelectedOption.businessUnit.mainValue = i.name;
        }
      }
    });

    this[list] = false;

    //this.setClientOption();
  }

  isDisableSubmitButton(objName) {
     //console.log('diableing');
     var bool:boolean = false;
     for(var key in this.popupSelectedOption[objName]) {
       if(this.popupSelectedOption[objName].hasOwnProperty(key)){
         //console.log(key,this.popupSelectedOption[objName][key])
         if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
           bool = true;
           break;
         }
       }
     }
     //console.log("bool",bool,this.popupSelectedOption[objName])
     return bool;
  }

  openModel(modalName) {
    $(modalName).modal('show');
  }
  closeModel(modalName) {
    $(modalName).modal('hide');
  }

  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }

  publishData() {
    console.log("Published..!");
  }

  // editRecord(item) {
  //   console.log("item=>", item);
  //   for(let ind=0;ind<this.popupBusinessLineData.length;ind++) {
  //     if(this.popupBusinessLineData[ind].name == item.businessUnit) {
  //       this.popupBusinessLineData[ind].selected = true;
  //       this.popupSelectedOption.businessUnit.mainValue = item.businessUnit;
  //       this.popupSelectedOption.businessUnit.prodName = item.productName;
  //       this.popupSelectedOption.businessUnit.macOUI = item.macOUI;
  //     } else {
  //       this.popupBusinessLineData[ind].selected = false;
  //     }
  //   }

  //   this.selectedItem = item;
    
  // }

  
  editRequested(item){
    
    this.popupSelectedOption.businessUnit.id = item.id;
    this.popupSelectedOption.businessUnit.mainValue = item.businessUnit;
    this.popupSelectedOption.businessUnit.prodName = item.productLineName;
    this.popupSelectedOption.businessUnit.macOUI = item.oui;
    this.popupSelectedOption.businessUnit.addressCount = item.quota;
    this.popupSelectedOption.businessUnit.requestType = item.requestType;
    this.openModel("#myModal");

  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
  }


}
