import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ExportMacInCsvService } from './../service/export-mac-in-csv.service';
import { sharedService } from './../service/shared-service.service';
import * as fileSaver from 'file-saver';
import { HttpResponse } from '@angular/common/http';

declare var $: any;



@Component({
  selector: 'app-generate-mac',
  templateUrl: './generate-mac.component.html',
  styleUrls: ['./../app.component.css', './generate-mac.component.css']
})
export class GenerateMacComponent implements OnInit {

  currentBusinessUnit: string = "";
  newCurrentBusinessUnit: string = "";
  currentProductItem: string = "";
  managementType: string = "";
  chooseManagementType: string = "";
  articles: any[] = [];
  productDetails: any[] = [];
  allRequests=[];
  articlesdata: any[] =[];
  generatedMacforToolManagement:any = '';
  macAddress:any='';
  error:any = '';
  success:any = '';

  private resetErrors(){
    this.success = '';
    this.error   = '';
  }


  managementListItem: any = [
    {
    name: "SELFMANAGED",
    selected: false,
    disabled: false,
  },
  {
    name: "TOOLMANAGED",
    selected: false,
    disabled: false,
  }
];


  popupControls: any = {
    popupForProductionList: false,
  }

  popupSelectedOption: any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
  }

  jsonData =  [
    {
      name: "Honeywell",
      mac_address: '22:33:44cf:76aq'
    },
    {
      name: 'Honeywell',
      mac_address: '28:43:46ls:54ed'
    },
    {
      name: 'Honeywell',
      mac_address: '68:17:94zh:02jx'
    },
  ];

  buList: boolean = false;
  buListforNewProduct: boolean = false;
  prodList: boolean = false;
  managementList: boolean = false;
  showDetails: boolean = false;
  toolManagementDetails:any = '';

  @HostListener('click', ['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
    if(event.target.className.indexOf('current-sel-opt') == -1) this.buList = this.prodList = this.managementList = this.popupControls.popupForProductionList = false;    
  }

  @ViewChild('closebutton', { static: false }) closebutton;
  @ViewChild('closebuttonMac', { static: false }) closebuttonMac;
  
  @ViewChild('productlineclosebutton', { static: false }) productclosebutton;
  @ViewChild('toolMgmtModel', { static: false }) toolMgmtModel:ElementRef;
  @ViewChild('errorModel', { static: false }) errorModel:ElementRef;
  
  generateMac: any = "";
  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient,
    private exportService: ExportMacInCsvService,
    private getService:sharedService
  ) { }

  ngOnInit() {
    
    this.getBusinessUnit();
    //this.getProductDetails();
    this.toolManagementDetails = this.fb.group({
      'serial': [null, [Validators.required,Validators.maxLength(4)]],
      'batch': [null],
      'other': [null],
    });
    
  }

  get f() {
    return this.toolManagementDetails.controls;
  }
 

  getBusinessUnit(): void {
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
         this.articlesdata = item.businessUnit;
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
          // console.log(this.allRequests=res);
        })
       
        console.log("List of business unit=>",this.articlesdata);
       
      },
      (err) => {
        this.articles = err;
      });
  }


  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool: boolean = false;
    for (var key in this.popupSelectedOption[objName]) {
      if (this.popupSelectedOption[objName].hasOwnProperty(key)) {
        if (this.popupSelectedOption[objName][key] == null || this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined) {
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }
  downloadCSV(){
    this.exportService.downloadFile(this.jsonData, 'jsontocsv');
  }
  toggleDropDownList(type) {
    if (type == 'BU') {
      this.buList = !this.buList;
      this.prodList = false;
    }else if (type == 'NPL') {
      this.buListforNewProduct = !this.buListforNewProduct;
      this.prodList = false;
    }else if(type== 'PL'){
      this.prodList = !this.prodList;
      this.buList = false;
      this.buListforNewProduct =false;
    } else if(type == 'CreateProduct') {
      this.popupControls.popupForProductionList = !this.popupControls.popupForProductionList;
    } else if(type == 'MT') {
      this.managementList = !this.managementList;
    }
  }

  dropdownOptionSelector(event, index, arr, list, selectItem) {
    event.stopPropagation();
    console.log(event, index, arr, list, selectItem)
    console.log(arr, this[arr])
    this[arr].forEach((i, v) => {
      i.selected = false;
      if (v == index) {
        i.selected = true;
        this[selectItem] = i.name;
        if (selectItem == 'currentProductItem') {
          this.managementType = i.type;
          this.toolManagementDetails.reset();
        } else if (selectItem == 'currentBusinessUnit') {
          this.currentProductItem = "";
          this.managementType = "";
          console.log('current business unit section calling prod list')
          this.getProductDetails();
          
        }else if (selectItem == 'newCurrentBusinessUnit') {
          this.currentProductItem = "";
          this.managementType = "";
        }
      }
    });

    this[list] = false;

    //this.setClientOption();
  }

  openProductCreation() {
    this.popupSelectedOption.businessUnit.mainValue = this.currentBusinessUnit;
    this.popupSelectedOption.businessUnit.mainValue = this.newCurrentBusinessUnit;
  }

  openGenerateMAC(){
    console.log($("#toolMgmtModel"));
    console.log(this.toolMgmtModel, this.errorModel,this.closebutton)
    this.resetErrors();
    let param = {
      "batchCode": this.toolManagementDetails.value.batch,
      "businessUnit": this.currentBusinessUnit,
      "factoryLocation": "Sipcot",
      "otherInfo": this.toolManagementDetails.value.other,
      "productLineName": this.currentProductItem,
      "requestType": this.managementType,
      "serialNumber": this.toolManagementDetails.value.serial
    }
    this.getService.generateMac(param).subscribe(res => {
      console.log(res);
        this.generatedMacforToolManagement = res.body;
        
        console.log('succes model')
      },
      (err) => {
        console.log(err);
        if(err.status==200){
            this.macAddress= err.error.text;
            this.toolManagementDetails.reset();
            this.openModel("#toolMgmtModel");
            console.log('err success 200')
        }
        if(err.status==406){
          this.error = err.error.message;
          this.toolManagementDetails.reset();
          console.log('error model')
          this.openModel('#errorModel');
          // setTimeout(()=>{    //<<<---    using ()=> syntax
          //   this.closeModel('#errorModel');
          // }, 3000);
        }
      }  
    );
  }

  openModel(modalName) {
    /* console.log(this[modalName],modalName)
    //console.log("modalName=>",modalName,modalName.nativeElement.className)
    modalName.nativeElement.click();
    //modalName.nativeElement.modal('show');
    console.log(modalName.nativeElement.className) */
    $(modalName).modal('show');
    console.log('updated')
  }
  closeModel(modalName) {
    //  this[modalName].nativeElement.className = 'modal hide';
     $(modalName).modal('hide');
  }

  downLoadFile(data: any, type: string) {
    let blob = new Blob([data], { type: type});
    let url = window.URL.createObjectURL(blob);
    let pwa = window.open(url);
    
    if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
        alert( 'Please disable your Pop-up blocker and try again.');
    }
}



  downloadMACAddress(): void {
    let productLineList =  this.currentProductItem;
    this.getService.downloadMAC_Address_api(productLineList).subscribe(res => { 

      // this.exportService.downloadFile(res, 'jsontocsv');

          

    // let blob = new Blob([res], { type: 'text/json; charset=utf-8'});
    // let url = window.URL.createObjectURL(blob);
    // let pwa = window.open(url);
    // window.location.href = res.url;
    // fileSaver.saveAs(blob, 'employees.json');
    // if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
    //     alert( 'Please disable your Pop-up blocker and try again.');
    // }
      // let output = res.body;

      let blob:any = new Blob([res], { type: 'text/json; charset=utf-8' });
      let dwldLink = document.createElement("a");
      const url= window.URL.createObjectURL(blob);
      
      dwldLink.setAttribute("href", res.url );
      window.location.href = res.url;
      dwldLink.setAttribute("download", "MAC Address List" + ".csv");
      dwldLink.style.visibility = "hidden";
      document.body.appendChild(dwldLink);
      dwldLink.click();
      document.body.removeChild(dwldLink);
      

      // let csvData = this.ConvertToCSV(res, ['name','mac_address']);
      // console.log(csvData)
      // let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
      // let dwldLink = document.createElement("a");
      // let url = URL.createObjectURL(blob);
      // let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
      // if (isSafariBrowser) {  //if Safari open in new window to save file with random filename.
      //     dwldLink.setAttribute("target", "_blank");
      // }
      // dwldLink.setAttribute("href", url);
      // dwldLink.setAttribute("download", "MAC Address List" + ".csv");
      // dwldLink.style.visibility = "hidden";
      // document.body.appendChild(dwldLink);
      // dwldLink.click();
      // document.body.removeChild(dwldLink);
    },
      (err) => {
          console.log(err)
      }
    ),
    error => console.log('Error downloading the file'),
    () => console.info('File downloaded successfully');
  }

  sendBusinessData() {
    console.log("Data to Send",this.popupSelectedOption.businessUnit);
    this.closebutton.nativeElement.click();
  }

  getProductDetails(): void {
    let BussinessUnitList =  this.currentBusinessUnit;
    console.log(this.currentBusinessUnit);
    this.productDetails = [];
    this.getService.getProductDetails_api(this.currentBusinessUnit).subscribe(
      (res: any[]) => {
        console.log("response prod=>",res)
        res.forEach( item => {
          console.log(item.productLineName);
          this.productDetails.push({
            name: item.productLineName,
            selected: false,
            disabled: false,
            type:item.requestType,
            businessUnit:item.businessUnit
          })
        })
        console.log("updated prod list=>",this.productDetails);
      },
      (err) => {
        this.productDetails = err;
      });
  }

  copyMacAddress() {
    var copyText = document.getElementsByClassName("mac-address")[0];
    var textArea = document.createElement("textarea");
    textArea.value = copyText.textContent;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand("Copy");
    textArea.remove();
  }

  enableDisableGenMacButton(){
    //return this.currentBusinessUnit && this.currentProductItem && 
    console.log(this.toolManagementDetails.status != 'VALID',this.toolManagementDetails)
    return this.toolManagementDetails.status != 'VALID';
  }

}

