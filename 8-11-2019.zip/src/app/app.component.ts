import { Component } from '@angular/core';
import { AuthService } from './auth/auth.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MAC-ALLOCATOR';
  constructor(private AuthService:AuthService){
    sessionStorage.setItem('USER_NAME','ELA');
    sessionStorage.setItem('USER_ROLE','ADMIN');
    // sessionStorage.setItem('USER_ROLE','USER');
    this.getLoginDetails();
  }

  getLoginDetails() {
    if(sessionStorage.getItem('USER_NAME')){
      this.AuthService.isLoggedIn = true;
    } else {
      this.AuthService.isLoggedIn = false;
    }

    if(sessionStorage.getItem('USER_ROLE')){
      if(sessionStorage.getItem('USER_ROLE') == 'ADMIN'){
        this.AuthService.isAdmin = true;
      } else if(sessionStorage.getItem('USER_ROLE') == 'USER'){
        this.AuthService.isAdmin = false;
      }
    }

  }
  
}
