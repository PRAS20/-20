import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OuiPopUpComponent } from './oui-pop-up.component';

describe('OuiPopUpComponent', () => {
  let component: OuiPopUpComponent;
  let fixture: ComponentFixture<OuiPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OuiPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OuiPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
