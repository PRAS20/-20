import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OuiRequestedProductComponent } from './oui-requested-product.component';

describe('OuiRequestedProductComponent', () => {
  let component: OuiRequestedProductComponent;
  let fixture: ComponentFixture<OuiRequestedProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OuiRequestedProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OuiRequestedProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
