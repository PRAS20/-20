import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.css']
})
export class ProductManagementComponent implements OnInit {
  @HostListener('click', ['$event'])
  clickInside(event) {
    if(event.target.className.indexOf('current-sel-opt') == -1) this.isBUListShow = this.isReqTypeListShow = false;    
  }
  myInp = "Ani";
  managementType: string = "";
  currentProductItem: string = "";
  articles: any[] = [];
  managementListItem: any = [
    {
      name: "Self Managed",
      selected: false,
      disabled: false,
    },
    {
      name: "Tool Managed",
      selected: false,
      disabled: false,
    }
  ];

  businessUnitList: any = [
    {
      name: "BU 1",
      selected: false,
      disabled: false
    },
    {
      name: "BU 2",
      selected: false,
      disabled: false
    },
    {
      name: "BU 3",
      selected: false,
      disabled: false
    },
    {
      name: "BU 4",
      selected: false,
      disabled: false
    },
    {
      name: "BU 5",
      selected: false,
      disabled: false
    },
    {
      name: "BU 6",
      selected: false,
      disabled: false
    }
  ]

  formData:any = {
    buName: {value:"",required:true},
    productName: {value:"",required:true},
    requestType: {value:"",required:true},
    macOUI: {value:"",required:false},
    addressCount: {value:"",required:false},
  };

  isBUListShow: boolean = false;
  isReqTypeListShow:boolean = false;

  constructor(
    private getService:sharedService
  ) { }

  ngOnInit() {
    this.getBusinessUnit();
  }

  getBusinessUnit(): void {
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
          console.log(item.businessUnit);
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
        })
        console.log(this.articles);
      },
      (err) => {
        this.articles = err;
      });
  }

  toggleDropDownList(type) {
    console.log(type)
    if (type == 'BU') {
      this.isBUListShow = !this.isBUListShow;
      this.isReqTypeListShow = false;
    }else if (type == 'ReqType') {
      this.isReqTypeListShow = !this.isReqTypeListShow;
      this.isBUListShow = false;
    }
  }




  dropdownOptionSelector(event, index, arr, list, selectItem) {
    event.stopPropagation();
    console.log(event, index, arr, list, selectItem)
    console.log(arr, this[arr])
    this[arr].forEach((i, v) => {
      i.selected = false;
      if (v == index) {
        i.selected = true;
        this.formData[selectItem].value = i.name;
        this.managementType = this.formData[selectItem].value
      
      }
    });

    this[list] = false;

    //this.setClientOption();
  }

  isDisableSubmitButton() {
    var disable = false;
    for(var key in this.formData){
      if(this.formData.hasOwnProperty(key)){
        let condition = this.formData[key].required && (this.formData[key].value == "" || this.formData[key].value == undefined || this.formData[key].value == null);
        if(condition){
          disable = true;
        }
      }
    }

    return disable;
  }

  submitProductData() {
    console.log(this.formData);
  }

  

}
