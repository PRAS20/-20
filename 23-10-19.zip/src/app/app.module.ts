import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { OuiPopUpComponent } from './oui-pop-up/oui-pop-up.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { GenerateMacComponent } from './generate-mac/generate-mac.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { OuiRequestedProductComponent } from './oui-requested-product/oui-requested-product.component';
import { ClientGeneratorComponent } from './client-generator/client-generator.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { NotAuthorizedComponent } from './not-authorized/not-authorized.component';
import { OuiStatisticsComponent } from './oui-statistics/oui-statistics.component';



@NgModule({
  declarations: [
    AppComponent,
    OuiPopUpComponent,
    FooterComponent,
    HeaderComponent,
    DashboardComponent,
    GenerateMacComponent,
    OuiRequestedProductComponent,
    ClientGeneratorComponent,
    ProductManagementComponent,
    NotAuthorizedComponent,
    OuiStatisticsComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    NgbModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  exports: [DashboardComponent,MatBottomSheetModule],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [OuiPopUpComponent]
})
export class AppModule { }
