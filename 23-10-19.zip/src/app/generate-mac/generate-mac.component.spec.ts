import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateMacComponent } from './generate-mac.component';

describe('GenerateMacComponent', () => {
  let component: GenerateMacComponent;
  let fixture: ComponentFixture<GenerateMacComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateMacComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateMacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
