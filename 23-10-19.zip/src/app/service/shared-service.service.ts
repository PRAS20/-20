import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class sharedService {
  baseUrl = 'http://localhost:9000/api';
  bussinessUnit: any[] = [];
  ouiDetails: any[] = [];
  clientDetails: any[] = [];
  productDetails : any[] = [];

  constructor(private http: HttpClient) { }
  

    getBussinessUnit_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/businessUnit`).pipe(
        map((res: any[]) => {
          this.bussinessUnit = res;
          return this.bussinessUnit;
      })
      );
    }

    getOUIDetails_api(): Observable<any> { 
      return this.http.get(`${this.baseUrl}/oui`).pipe(
        map((res: any [])=>{
          this.ouiDetails=res;
          return this.ouiDetails;
        })
      );
    }

    getClientDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/client`).pipe(
        map((res: any [])=>{
            this.clientDetails=res;
            return this.clientDetails;
        })
      );
    }

    getProductDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/productLines`).pipe(
        map((res: any[])=>{
          this.productDetails =res;
          return this.productDetails;
        })
      )
    }
  
}
