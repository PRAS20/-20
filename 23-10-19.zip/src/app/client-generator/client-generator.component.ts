import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';

@Component({
  selector: 'app-client-generator',
  templateUrl: './client-generator.component.html',
  styleUrls: ['./../app.component.css','./client-generator.component.css']
})
export class ClientGeneratorComponent implements OnInit {

  clientDetails: any [] = [];
  productDetails: any[] = [];
  clientNamePop:boolean = false;
  productNamePop:boolean = false;
  selectedClientOption:string = "Select a Client";
  selectedProductOption:string = "";
 
  
  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient,
    private getService:sharedService
    ){ }

  ngOnInit() {
    this.getClientDetails();
    this.getProductDetails();
  }

  getClientDetails(): void {
    this.getService.getClientDetails_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
          console.log(item.clientName);
          this.clientDetails.push({
            name: item.clientName,
            selected: false,
            disabled: false
          })
        })
        console.log(this.clientDetails);
      },
      (err) => {
        this.clientDetails = err;
      });
  }

  getProductDetails(): void {
    this.getService.getProductDetails_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
          console.log(item.productLineName);
          this.productDetails.push({
            name: item.productLineName,
            selected: false,
            disabled: false
          })
        })
        console.log(this.productDetails);
      },
      (err) => {
        this.productDetails = err;
      });
  }

  toggleClientPop() {
    this.productNamePop = false;
    this.clientNamePop = !this.clientNamePop;
   
  }


  clientOptionSelector(event,index) {
    event.stopPropagation();
    this.clientDetails.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedClientOption = i.name;
      }
    });
    this.clientNamePop = false;
    //this.setClientOption();
  }

  productOptionSelector(event,index) {
    event.stopPropagation();
    this.productDetails.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedProductOption = i.name;
      }
    });
    this.productNamePop = false;
    //this.setClientOption();
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    console.log(event,index,arr,selection,showVar,unitName);
    console.log(this[arr])
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
  }


  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }



}
