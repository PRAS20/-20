import { Component, OnInit } from '@angular/core';
import { AddDeviceService } from '../service/commonSer.service'
import {NgbModal,NgbActiveModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['../home/home.component.css']
})
export class DashboardComponent implements OnInit {
  totalCount:any;
  currentUsed:any;
  notUsed:any;
  notWorked:any;
  ipadCount:any;
  ipadProCount:any;
  ipadPhoneCount:any;
  androidCount:any;
  laptopCount:any;
  macCount:any;
  result:any;
  error = '';
  success = '';
  notUsedDetails:any;
  notWorkedDetails:any;
  currentWorkedDetails:any;
  totalWorkedDetails:any;

  constructor(private AddDeviceService: AddDeviceService,public Modal: NgbModal) { }
  ngOnInit() { 
    this.devDatasev();
    this.Datasev();
  }
  activeModal: NgbActiveModal

  closePopUp(){
    this.activeModal.close(); 
  }

  devDatasev(): void {
    this.AddDeviceService.count().subscribe(
      (res) => {
        this.totalCount = ((res["totCount"]/100)*100); 
        this.currentUsed = ((res["currentUsed"]/100)*100); 
        this.notUsed = ((res["notUsed"]/100)*100); 
        this.notWorked = ((res["notWorked"]/100)*100); 
        this.ipadCount = res["ipadCount"]; 
        this.ipadProCount = res["ipadProCount"]; 
        this.ipadPhoneCount = res["ipadPhoneCount"]; 
        this.androidCount = res["androidCount"]; 
        this.laptopCount = res["laptopCount"]; 
        this.macCount = res["macCount"]; 
      }    
    );
  }
  Datasev(): void {
    this.AddDeviceService.notWorking().subscribe(
      (res) => {
        this.notUsedDetails = res["notUsedDetails"];
        this.notWorkedDetails = res["notWork"];
        this.currentWorkedDetails = res["currUsedDetails"];
        this.totalWorkedDetails = res["totalUsedDetails"];
      },
      (err) => {
        this.error = err;
      }
    );
  }

  notWorkedPopup(notWorking_Popup){
    this.Modal.open(notWorking_Popup); 
  }
  notUsedPopup(notUsed_Popup){
    this.Modal.open(notUsed_Popup); 
  }
  currentUsedPopup(currentUsed_Popup){
    this.Modal.open(currentUsed_Popup); 
  }
  totalUsedPopup(totalUsed_Popup){
    this.Modal.open(totalUsed_Popup); 
  }
}
