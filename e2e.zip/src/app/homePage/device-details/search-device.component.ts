import { Component, OnInit, Input} from '@angular/core';
import { AddDeviceService } from '../service/commonSer.service'
import { Device } from '../show-device/showAlldevice';
import {NgbModal,NgbActiveModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-search-device',
  templateUrl: './search-device.component.html',
  styleUrls: ['../home/home.component.css'],
  providers: [DatePipe]
})

export class DeviceDetailsComponent implements OnInit {
 //maxDate = new Date();
 maxDate =  new Date(new Date().setDate(new Date().getDate()-1))

  deviceData: Device[];
  error = '';
  success = '';
  closeResult: string;
  myDate = new Date();
  jstoday = '';
  now = new Date;
  todayDate: string ;
    constructor(private datePipe: DatePipe,private AddDeviceService: AddDeviceService,private modalService: NgbModal) {
      this.jstoday = this.datePipe.transform(this.myDate, 'dd-MMMM-yyy,hh:mm:ss aaa');
      this.todayDate =this.datePipe.transform(new Date(), 'yyyy-MM-dd')   
    }
    
  
    ngOnInit() {
      this.devDatasev();
      
    }
    devDatasev(): void {
      this.AddDeviceService.getAll().subscribe(
        (res: Device[]) => {
          this.deviceData = res;
        },
        (err) => {
          this.error = err;
        }
      );
    }
   
    details(content) {
      const modalService = this.modalService.open(DetailsPopup);
      modalService.componentInstance.content = content;
    }
    Update(tag){
      const modalService = this.modalService.open(UpdatePopup);
      modalService.componentInstance.tag = tag;
    }
    Release(releaseRow){
      const modalService = this.modalService.open(ReleasePopup);
      modalService.componentInstance.releaseRow = releaseRow;
    }
}

@Component({
  selector: 'details_popup',
  templateUrl: './info/details.html',
  styleUrls: ['../home/home.component.css']
})
export class DetailsPopup {

  deviceData: Device[];
  error = '';
  success = '';
  closeResult: string;
    constructor(private AddDeviceService: AddDeviceService,public activeModal: NgbActiveModal) {
    }
    ngOnInit() {
      this.devDatasev();
    }
    closePopUp(){
      this.activeModal.close(); 
    }
    devDatasev(): void {
      this.AddDeviceService.getAll().subscribe(
        (res: Device[]) => {
          this.deviceData = res;

        },
        (err) => {
          this.error = err;
        }
      );
    }
 }

@Component({
  selector: 'tag_popup',
  templateUrl: './info/tag.html',
  styleUrls: ['../home/home.component.css']
})
export class UpdatePopup { 
  deviceData: Device[];
  @Input() public tag;
  error = '';
  success = '';
  closeResult: string;
    constructor(private AddDeviceService: AddDeviceService,public activeModal: NgbActiveModal,public Modal: NgbModal) { }
    ngOnInit() {
      this.devDatasev();
    }
    private resetErrors(){
      this.success = '';
      this.error   = '';
    }
    closePopUp(){
      this.activeModal.close(); 
    }
    devDatasev(): void {
      this.AddDeviceService.getAll().subscribe(
        (res: Device[]) => {
          this.deviceData = res;
        },
        (err) => {
          this.error = err;
        }
      );
    }

    update(tag,UpdateResult_popup){
      this.resetErrors();
      this.AddDeviceService.update(tag)
        .subscribe(
          (res) => {
            this.deviceData    = res;
            this.success = 'Updated successfully';
            this.activeModal.close(); 
            setTimeout(()=>{    //<<<---    using ()=> syntax
              this.Modal.open(UpdateResult_popup); 
            }, 500);
            // this.activeModal.close(UpdateResult_popup); 
          },
          (err) => this.error = err
        );
    }

}

@Component({
  selector: 'release_popup',
  templateUrl: './info/release.html',
  styleUrls: ['../home/home.component.css']
})
export class ReleasePopup { 
  @Input() public releaseRow;

  error = '';
  success = '';
  releaseData: Device[];
  constructor(private AddDeviceService: AddDeviceService,public activeModal: NgbActiveModal,public Modal: NgbModal) {}

  private resetErrors(){
    this.success = '';
    this.error   = '';
  }
  
  closePopUp(){
    this.activeModal.close();  
  }
  release(releaseRow, releaseResult_popup){
    this.resetErrors();
    this.AddDeviceService.release(releaseRow)
      .subscribe(
        (res) => {
          this.releaseData    = res;
          this.success = 'Released Successfully ';
          this.activeModal.close(); 
          setTimeout(()=>{    //<<<---    using ()=> syntax
            this.Modal.open(releaseResult_popup)
       }, 500);  
          
        },
        (err) => this.error = err
      );
  }

 
  
}