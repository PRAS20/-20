
export class Device {
    constructor(){}

    deviceType:any;
    taggedFrom:any;
    taggedTo:any;
    modelName:any;
    modelNum:any;
    serialNum:any;
    labelName:any;
    assetID:any;
    udid:any;
    tagged:any;
    Comments:any;
    status:any;
    s_no?:   number;
}
