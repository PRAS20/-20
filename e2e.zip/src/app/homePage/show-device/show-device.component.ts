import { Component, OnInit } from '@angular/core';
import { Device } from './showAlldevice';
import { AddDeviceService } from '../service/commonSer.service'
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-show-device',
  templateUrl: './show-device.component.html',
  styleUrls: ['../home/home.component.css'],
  providers: [DatePipe]
})
export class ShowDeviceComponent implements OnInit {
 
  deviceData: Device[];
  error = '';
   success = '';
  myDate = new Date();
  jstoday = '';
  constructor(private datePipe: DatePipe,private AddDeviceService: AddDeviceService) {
    this.jstoday = this.datePipe.transform(this.myDate, 'dd-MMMM-yyy,hh:mm:ss aaa');
  }

  ngOnInit() {
    this.devDatasev();
  }

  devDatasev(): void {
    this.AddDeviceService.getAll().subscribe((res: Device[]) => {this.deviceData = res;},(err) => {this.error = err;});
  }

}
