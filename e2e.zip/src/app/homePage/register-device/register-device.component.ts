import { Component, OnInit } from '@angular/core';
import { Device } from '../show-device/showAlldevice';
import { AddDeviceService } from '../service/commonSer.service'
import {NgbModal,NgbActiveModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-register-device',
  templateUrl: './register-device.component.html',
  styleUrls: ['../home/home.component.css']
})
export class RegisterDeviceComponent implements OnInit {

 
  //addDevice: showAllDevice[];
    error = '';
    success = '';
    titleText='* All are mandatory fields';
    
  constructor(private addDeviceService: AddDeviceService,public Modal: NgbModal) { }
  allDevice = new Device();

  ngOnInit() {

    this.allDevice.deviceType="Choose any device";
    this.allDevice.status="Device Status";
  }


  private resetErrors(){
    this.success = '';
    this.error   = '';
  }


  addCar(f,success_popup,error_popup) {
    this.resetErrors();
    if(this.allDevice.deviceType =="Choose any device"){
        alert("Choose any device ");
        (err) => this.error = err
      }
      else if(this.allDevice.status=="Device Status"){
        alert("Select Device Status ");
        (err) => this.error = err
      }
    this.addDeviceService.store(this.allDevice)
      .subscribe(
        (res) => {
          // Update the list of data
         // this.addDevice = res;
          // Inform the user
          this.success = 'Created successfully';
          setTimeout(()=>{    //<<<---    using ()=> syntax
            this.Modal.open(success_popup); 
          }, 500);
        
          
          // Reset the form
          f.reset();
        },
        (err) => {
          if(this.error = err){
          setTimeout(()=>{    //<<<---    using ()=> syntax
            this.Modal.open(error_popup); 
            
          }, 500);
        }
        }
      );
  }

}
