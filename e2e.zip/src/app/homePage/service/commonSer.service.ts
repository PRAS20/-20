import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Device } from '../show-device/showAlldevice';

@Injectable({
  providedIn: 'root'
})
export class AddDeviceService {
    baseUrl = 'https://10.219.69.39/api';
    addDevice: Device[];
    Result:any={totCount:"",currentUsed:"",notUsed:"",notWorked:"",ipadCount:"",ipadProCount:"",ipadPhoneCount:"",androidCount:"",laptopCount:"",macCount:""};
    DeviceDetails:any={notUsedDetails:"",notWork:"",currUsedDetails:"",totalUsedDetails:""};
    constructor(private http: HttpClient) { }

    private handleError(error: HttpErrorResponse) {
      console.log(error);
      // return an observable with a user friendly message
      return throwError('Error! something went wrong.');
    }
      //To get all device details 
  getAll(): Observable<Device[]> {
    return this.http.get(`${this.baseUrl}/list`).pipe(
      map((res) => {
        this.addDevice = res['data'];
        return this.addDevice;
    }),
    catchError(this.handleError));
  }
    //To get list of not working devices

    notWorking() {
      return this.http.get(`${this.baseUrl}/count`).pipe(map((res) => {
          this.DeviceDetails.notUsedDetails = res['notUsedDetails'];
          this.DeviceDetails.notWork =res['notWork'];  
          this.DeviceDetails.currUsedDetails =res['currUsedDetails']; 
          this.DeviceDetails.totalUsedDetails =res['totalUsedDetails'];   
          return this.DeviceDetails;
      }),
      catchError(this.handleError));
    }
  
    // To get totalCount,currentlyUsedCount,notUsedCount and notWorkedCount devices 
  count(){
    return this.http.get(`${this.baseUrl}/count`).pipe(map((totCountResult) => { 
           this.Result.totCount =totCountResult['totCount'];
           this.Result.currentUsed =totCountResult['currentUsed'];
           this.Result.notUsed =totCountResult['notUsed'];
           this.Result.notWorked =totCountResult['notWorked'];
           this.Result.ipadCount =totCountResult['ipadCount'];
           this.Result.ipadProCount =totCountResult['ipadProCount'];
           this.Result.ipadPhoneCount =totCountResult['ipadPhoneCount'];
           this.Result.androidCount =totCountResult['androidCount'];
           this.Result.laptopCount =totCountResult['laptopCount'];
           this.Result.macCount =totCountResult['macCount'];
           return this.Result;
      }),
    catchError(this.handleError));
  }
    // To insert device details 
  store(allDevice: Device): Observable<Device[]> {
    return this.http.post(`${this.baseUrl}/store`, { data: allDevice })
      .pipe(map((res) => {
        return (res['data']);
      }),
      catchError(this.handleError));
  }
  // Update Assinged Date From and To. 
  update(addDevice: Device): Observable<Device[]> {
    return this.http.put(`${this.baseUrl}/update`, { data: addDevice })
      .pipe(map((res) => {
        const deviceUp = this.addDevice.find((items) => {
          return +items['s_no'] === +addDevice['s_no'];        
        });
        if (deviceUp) {      
          deviceUp['tagged'] = addDevice['tagged'];
          deviceUp['taggedFrom'] = addDevice['taggedFrom'];
          deviceUp['taggedTo'] = addDevice['taggedTo'];
        }
        return this.addDevice;
      }),
      catchError(this.handleError));
  }
   // Release and automatically assigned to digitalFactory. 
  release(addDevice: Device): Observable<Device[]> {
    return this.http.put(`${this.baseUrl}/release`, { data: addDevice })
      .pipe(map((res) => {
        const release = this.addDevice.find((items) => {
          return +items['s_no'] === +addDevice['s_no'];        
        });
        if (release) {      
          release['tagged'] = addDevice['tagged'];
        }
        return this.addDevice;
      }),
      catchError(this.handleError));
  }

}