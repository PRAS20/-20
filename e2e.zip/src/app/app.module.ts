import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { MatNativeDateModule } from '@angular/material';
import { AppComponent } from './app.component';
import { SignInComponent } from './signInPage/index.component';
import { SignIn_PopUp } from './signInPage/signIn_Pop-Up/sign-in.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './homePage/home/home.component';
import { HeaderComponent } from './homePage/header/header.component';
import { FooterComponent } from './homePage/footer/footer.component';
import { SidebarComponent } from './homePage/sidebar/sidebar.component';
import { ShowDeviceComponent } from './homePage/show-device/show-device.component';
import { DeviceDetailsComponent,DetailsPopup,UpdatePopup,ReleasePopup} from './homePage/device-details/search-device.component';
import { DemoMaterialModule } from './material-module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RegisterDeviceComponent } from './homePage/register-device/register-device.component';
import { DashboardComponent } from './homePage/dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { AppService } from './app.service';
@NgModule({
  declarations: [
    AppComponent,
    SignInComponent,
    SignIn_PopUp,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    ShowDeviceComponent,
    DeviceDetailsComponent,
    DetailsPopup,
    UpdatePopup,
    ReleasePopup,
    RegisterDeviceComponent,
    DashboardComponent,
  ],
  entryComponents: [SignIn_PopUp,DetailsPopup,UpdatePopup,ReleasePopup],

  imports: [
    BrowserModule,
    MatNativeDateModule,
    DemoMaterialModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule    
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
