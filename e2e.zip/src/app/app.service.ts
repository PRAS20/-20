
import { Router } from '@angular/router';
import {HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';



@Injectable()
export class AppService {

    private authenticateUrl: string = 'https://digifactory.cognizant.com/tools/pixelperfect_working/api/controllers/authenticate.php';
      //assocId: number = 440269; 
      assocId: number = 426884;
      sessionId: string = 'null';
      projectId: string;
      projectName: string = '';
      loginFlag = false;
      username: string = null;
      mailId: string = null;
      enableQuickCompare: boolean = true;
  
      constructor(
          private http: HttpClient,
          private router: Router
      ) { }

      login(postData: any): Promise<any> {
        let headers = new Headers({ "Content-Type": "application/json" });
        return this.http.post(this.authenticateUrl, { data: postData })
            .toPromise()
        //  .then(response =>response.json())
        //  .catch(this.handleError);
    }

    checkLocalStorageValues() {
        if (localStorage.getItem("pixelUserId") == null) {
            this.assocId = null;
            this.loginFlag = false;
            this.username = null;
            this.mailId = null;
            this.router.navigate(['/signin']);
        } else {
            this.assocId = +localStorage.getItem("pixelUserId");
            this.loginFlag = true;
            this.username = localStorage.getItem("pixelUserName");
            this.mailId = localStorage.getItem("pixelUserMailId");
        }
    }

    private handleError(error: any): Promise<any> {
        // console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
}