import { NgModule } from '@angular/core';
import { Routes, RouterModule,RouterLinkActive } from '@angular/router';
import { SignInComponent } from './signInPage/index.component';
import { HomeComponent } from './homePage/home/home.component';
import { ShowDeviceComponent } from './homePage/show-device/show-device.component';
import { DeviceDetailsComponent,DetailsPopup,UpdatePopup,ReleasePopup} from './homePage/device-details/search-device.component';
import { RegisterDeviceComponent } from './homePage/register-device/register-device.component';
import { DashboardComponent } from './homePage/dashboard/dashboard.component';
import { SignIn_PopUp } from './signInPage/signIn_Pop-Up/sign-in.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'logOut',
    pathMatch: 'full'
  },
  {
    path: 'signin',
    component: SignInComponent
  },
  {
    path: 'signinPopUP',
    component: SignIn_PopUp
  },
  {
    path: 'homepage',
    component: HomeComponent,
    children: [
      { path: "", redirectTo: "dashboard", pathMatch: "full" },
      { 
        path: 'dashboard',
        component: DashboardComponent
      },
      {
        path: 'Showdevice',
        component: ShowDeviceComponent
      },
      {
        path: 'Devicedetails',
        component: DeviceDetailsComponent
      },
      {
        path:'RegisterDevice',
        component:RegisterDeviceComponent
      }
    ]
  },
  { path: "**", component: SignInComponent },
  { path: "", redirectTo: "signin", pathMatch: "full" }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
