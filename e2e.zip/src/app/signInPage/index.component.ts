import { Component, OnInit } from '@angular/core';
import { SignIn_PopUp } from './signIn_Pop-Up/sign-in.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';


@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class SignInComponent implements OnInit {
  modalReference :any;
  constructor(private signIn: NgbModal,private router:Router) {

  }
  showBottomSheet() {
    // this.modalReference = this.signIn.open(SignIn_PopUp);
    this.router.navigate(['./homepage']);
  }

  ngOnInit() {

  }

  closeDialog() {
    this.modalReference.close();
  }

}
