import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal,NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { AppService } from '../../app.service';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['../index.component.css']
})
export class SignIn_PopUp  {

  usernameFlag:any = false;
	passwordFlag:any = false;
	validLogin:any = false;
	authUser:any = false;
	username:any = "";
	password:any = "";
  guestStatus:any = '';
  loginStatus:any = false

  constructor(private router: Router,public activeModal: NgbActiveModal,private appService: AppService) { }
  
  ngOnInit(){
    
  
  }
  login() {
    if (this.username == 'admin' && this.password == 'admin') {
      this.loginStatus = true;
      this.activeModal.close(); 
      this.router.navigate(["homepage"]);
      
    } else {
      alert("Invalid credentials");
    }
  }

   
}