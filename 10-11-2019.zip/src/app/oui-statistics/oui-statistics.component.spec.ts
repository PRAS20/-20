import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OuiStatisticsComponent } from './oui-statistics.component';

describe('OuiStatisticsComponent', () => {
  let component: OuiStatisticsComponent;
  let fixture: ComponentFixture<OuiStatisticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OuiStatisticsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OuiStatisticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
