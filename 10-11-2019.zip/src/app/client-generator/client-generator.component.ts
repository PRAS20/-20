import { Component,Input, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';
import { HttpErrorResponse } from '@angular/common/http';
declare var $: any;

@Component({
  selector: 'app-client-generator',
  templateUrl: './client-generator.component.html',
  styleUrls: ['./../app.component.css','./client-generator.component.css']
})
export class ClientGeneratorComponent implements OnInit  {

  clientDetails: any [] = [];
  productDetails: any[] = [];
  clientNamePop:boolean = false;
  productNamePop:boolean = false;
  selectedClientOption:string = "Select a Client";
  selectedProductOption:string = "";
  clientRegistration:any='';
  requestTypeDetails: any[] = [];
  error:any = '';
  success:any = '';
  private resetErrors(){
    this.success = '';
    this.error   = '';
  }
  
  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    private fb: FormBuilder,
    private getService:sharedService,
    ){ }
 

    
  
  ngOnInit() {
    this.getClientDetails();
    this.getProductDetails();
    this.clientRegistration = this.fb.group({
      'productLineName': ['',[Validators.required]],
      'test': [null, [Validators.required,Validators.minLength(2)]],
      'requestedBy':'System'
     });
  }

  get f() {
    return this.clientRegistration.controls;
  }

  sendClientData(){
    this.resetErrors();
    let data = this.clientRegistration.value;
    console.log(data);
    // this.getService.createClient(data).subscribe(res => { 
    //   console.log(res.body)
    //   let output = res.body;
    //  },
    //  (err) => {
    //    console.log(err);
    //   if(err.status==200){
    //     this.success = 'New Product Requested Successfully';
    //     this.clientRegistration.reset();
    //   }if(err.status==500){
    //     this.error = "Internal Server Error";
    //   }if(err.status==400){
    //     this.error = err.error.message;
    //   }
    //   else{
    //     this.error = err.error.message;
    //   }
    // }
    // );  
  }
  
  
  getClientDetails(): void {
    this.getService.getClientDetails_api().subscribe(
      (res: any[]) => {
        this.clientDetails = res;
        console.log(this.clientDetails);
      },
      (err) => {
        this.clientDetails = err;
      });
  }
  clientPopUp(){
    this.openModel("#clientNameModal");
  }
  getProductDetails(): void {
    let businessUnitData = '';
    this.getService.getProductDetails_api(businessUnitData).subscribe(
      (res: any[]) => {
        res.forEach( item => {
 
          console.log(item.requestType);
          if(item.requestType !="Self Managed"){
            this.productDetails.push({
              name: item.productLineName,
              selected: false,
              disabled: false
            })
          }
          
        })
      },
      (err) => {
        this.productDetails = err;
      }); 
  }

  toggleClientPop() {
    this.productNamePop = false;
    this.clientNamePop = !this.clientNamePop;
   
  }

  openModel(modalName) {
    $(modalName).modal('show');
  }

  clientOptionSelector(event,index) {
    event.stopPropagation();
    this.clientDetails.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedClientOption = i.name;
      }
    });
    this.clientNamePop = false;
    //this.setClientOption();
  }

  productOptionSelector(event,index) {
    event.stopPropagation();
    this.productDetails.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedProductOption = i.name;
      }
    });
    this.productNamePop = false;
    //this.setClientOption();
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    console.log(event,index,arr,selection,showVar,unitName);
    console.log(this[arr])
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
    if(unitName == 'productLine') {
      this.clientRegistration.controls['productLineName'].setValue( this.popupSelectedOption.productLine.mainValue);
    }
  }


  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  



}
