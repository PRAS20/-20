import { Component, OnInit, HostListener, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
declare var $: any;

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.css']
})
export class ProductManagementComponent implements OnInit {
  @HostListener('click', ['$event'])
  clickInside(event) {
    if(event.target.className.indexOf('current-sel-opt') == -1) this.isBUListShow = this.isReqTypeListShow = false;    
  }

  managementType: string = "";
  currentProductItem: string = "";
  articles: any[] = [];
  productRequestForm:any='';
  currentBusinessUnit: string = "";
  error:any = '';
  success:any = '';
   
  private resetErrors(){
    this.success = '';
    this.error   = '';
  }

  managementListItem: any = [
    {
      name: "SELFMANAGED",
      selected: false,
      disabled: false,
    },
    {
      name: "TOOLMANAGED",
      selected: false,
      disabled: false,
    }
  ];

  isBUListShow: boolean = false;
  isReqTypeListShow:boolean = false;

  constructor(
    private fb: FormBuilder,
    private getService:sharedService
  ) { }

  ngOnInit() {
    this.getBusinessUnit();
    this.productRequestForm = this.fb.group({
      'businessUnit':['',[Validators.required]],
      'productLineName': [null, [Validators.required,Validators.minLength(2)]],
      'requestType':['',[Validators.required]],
      'oui': [''],
      'quota': ['0'],
      'requestedBy':'System'
    });
  }

  checkNullvalue(){
    if(this.productRequestForm.value.quota==null){
      this.productRequestForm.controls['quota'].patchValue('0');
      this.productRequestForm.controls['requestedBy'].patchValue('System');
    }
  }

  get f() {
    return this.productRequestForm.controls;
  }

  getBusinessUnit(): void {
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
          console.log(item.businessUnit);
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
        })
        console.log(this.articles);
      },
      (err) => {
        this.articles = err;
      });
  }

  toggleDropDownList(type) {
    console.log(type)
    if (type == 'BU') {
      this.isBUListShow = !this.isBUListShow;
      this.isReqTypeListShow = false;
    }else if (type == 'ReqType') {
      this.isReqTypeListShow = !this.isReqTypeListShow;
      this.isBUListShow = false;
    }
  }


  dropdownOptionSelector(event, index, arr, list, selectItem) {
    event.stopPropagation();
    console.log(event, index, arr, list, selectItem)
    console.log(arr, this[arr])
    this[arr].forEach((i, v) => {
      i.selected = false;
      if (v == index) {
        i.selected = true;
        this.productRequestForm[selectItem] = i.name;
        this.managementType = this.productRequestForm[selectItem];
        if(selectItem == 'buName'){
          this.productRequestForm.controls['businessUnit'].setValue( i.name);
        }
        if(selectItem == 'requestType'){
          this.productRequestForm.controls['requestType'].setValue( i.name);
        }
      }
    });

    this[list] = false;

    //this.setClientOption();
  }


  @ViewChild('toolMgmtModel', { static: false }) toolMgmtModel;
  
  display='none';
  
  submitProductData() {
    this.resetErrors();
    this.checkNullvalue();
      let data = this.productRequestForm.value;
      this.getService.createProductLine(data).subscribe(res => { 
        let output = res.body.data;
      },
      (err) => {
        if(err.status==200){
          this.success = 'New Product Requested Successfully';
          this.productRequestForm.reset();
          this.openModel("#toolMgmtModel");
          // setTimeout(()=>{    //<<<---    using ()=> syntax
          //   this.closeModel('#toolMgmtModel');
          // }, 4000);
        }if(err.status==500){
          this.error = "Internal Server Error";
        }if(err.status==400){
          this.error = err.error.message;
        }
        else{
          this.error = err.error.message;
        }
      }

      ); 

  }

  openModel(modalName) {
    $(modalName).modal('show');
    console.log('updated')
  }
  closeModel(modalName) {
     $(modalName).modal('hide');
  }
  

}
