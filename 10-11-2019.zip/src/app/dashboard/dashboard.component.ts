import { Component, OnInit, } from '@angular/core';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./../app.component.css','./dashboard.component.css']

})
export class DashboardComponent implements OnInit {

  constructor() {
   }

  selectedDevice;
  ngOnInit() {
    this.selectedDevice = 'Select Any Option !';
  }
  devices = 'one two three'.split(' ');
 
  onChange(deviceValue) {
    console.log(deviceValue);
    this.selectedDevice = deviceValue;
}

 
}
