import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class sharedService {
  // baseUrl = 'http://localhost:8080/api';
  baseUrl = 'http://localhost/hbtAPI';
  
  // baseUrl = 'http://hbtmacallocator-env-1.gkpwpcsmeb.us-east-1.elasticbeanstalk.com/api';
  bussinessUnit: any[] = [];
  ouiDetails: any[] = [];
  clientDetails: any[] = [];
  productDetails : any[] = [];
  productRequestDetails : any[] = [];
  clientRequestDetails : any[] = [];
  downloadMACAddressList: any[] = [];

  constructor(private http: HttpClient) { }

  private handleError(error: HttpErrorResponse) {
    console.log(error);
    // return an observable with a user friendly message
    return throwError('Error! something went wrong.');
  }
  

    getBussinessUnit_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/businessUnit.php`).pipe(
        map((res: any[]) => {
          this.bussinessUnit = res;
          return this.bussinessUnit;
      })
      );
    }

    getOUIDetails_api(): Observable<any> { 
      return this.http.get(`${this.baseUrl}/oui`).pipe(
        map((res: any [])=>{
          this.ouiDetails=res;
          return this.ouiDetails;
        })
      );
    }

    getClientDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/client/tokens/503130671`).pipe(
        map((res: any [])=>{
            this.clientDetails=res;
            return this.clientDetails;
        })
      );
    }

    getProductDetails_api(dataInput:any): Observable<any> {
  
      return this.http.get(`${this.baseUrl}/productLine.php`);
    }

    getProductRequestDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/allProduct.php`).pipe(
        map((res: any[])=>{
          this.productRequestDetails = res;
          return this.productRequestDetails;
        })
      )
    }

    getClientRequestDetails_api(): Observable<any> {
      return this.http.get(`${this.baseUrl}/allClient.php`).pipe(
        map((res: any[])=>{
          this.clientRequestDetails = res;
          return this.clientRequestDetails;
        })
      )
    }

    downloadMAC_Address_api(dataInput:any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type' : 'application/json'
      }); 
      return this.http.get(`${this.baseUrl}/productline/selfManaged/macids?productLineName=${dataInput}`, {
        headers: httpHeaders,
        observe: 'response',
        responseType: 'blob' as 'json'
      }
      );
    }

    createClient(dataInput:any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type' : 'application/json'
      }); 
      console.log(dataInput);
      return this.http.post(`${this.baseUrl}/client/request`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      )
    }

    createProductLine(dataInput:any): Observable<any>{
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      console.log(dataInput);
      return this.http.post(`${this.baseUrl}/productLine/request`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      );  
    }

    generateMac(dataInput:any): Observable<any>{
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      console.log(dataInput);
      return this.http.post(`${this.baseUrl}/productline/toolManaged/macids`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      );  
    }

    updateClientRequest(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/updateClient.php`,dataInput,{
        headers: httpHeaders,
        observe: 'response'
      } 
      );
        
    }

    updateProductRequest(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/productLine/management`,dataInput,
        {
          headers: httpHeaders,
          observe: 'response'
        }
      );  
       
    }

    updateExistingProduct(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/productLine/management`,dataInput,
      {
        headers: httpHeaders,
        observe: 'response'
      }
      );
    }

    updateExistingClient(dataInput: any): Observable<any> {
      let httpHeaders = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      return this.http.post(`${this.baseUrl}/updateClient.php`,dataInput,
      {
        headers: httpHeaders,
        observe: 'response'
      }
      );
    }

    errorResponse(err) {
      if (err.error instanceof Error) {
        //A client-side or network error occurred.				 
        console.log('An error occurred:', err.error.message);
      } else {
        //Backend returns unsuccessful response codes such as 404, 500 etc.				 
        console.log('Backend returned status code: ', err.status);
        console.log('Response body:', err.error);
      }
    }
  
  
}
