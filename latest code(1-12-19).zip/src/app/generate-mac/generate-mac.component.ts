import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ExportMacInCsvService } from './../service/export-mac-in-csv.service';
import { sharedService } from './../service/shared-service.service';
import * as fileSaver from 'file-saver';
import { HttpResponse } from '@angular/common/http';

declare var $: any;



@Component({
  selector: 'app-generate-mac',
  templateUrl: './generate-mac.component.html',
  styleUrls: ['./../app.component.css', './generate-mac.component.css']
})
export class GenerateMacComponent implements OnInit {

  currentBusinessUnit: any = "";
  newCurrentBusinessUnit: string = "";
  currentProductItem: string = "";
  managementType: string = "";
  chooseManagementType: string = "";
  articles: any[] = [];
  productDetails: any[] = [];
  allRequests=[];
  articlesdata: any[] =[];
  generatedMacforToolManagement:any = '';
  macAddress:any='';
  error:any = '';
  success:any = '';
  checkValue:boolean=true;
  private resetErrors(){
    this.success = '';
    this.error   = '';
  }


  managementListItem: any = [
    {
    name: "SELFMANAGED",
    selected: false,
    disabled: false,
  },
  {
    name: "TOOLMANAGED",
    selected: false,
    disabled: false,
  }
];


  popupControls: any = {
    popupForProductionList: false,
  }

  popupSelectedOption: any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
  }

  jsonData =  [
    {
      name: "Honeywell",
      mac_address: '22:33:44cf:76aq'
    },
    {
      name: 'Honeywell',
      mac_address: '28:43:46ls:54ed'
    },
    {
      name: 'Honeywell',
      mac_address: '68:17:94zh:02jx'
    },
  ];

  buList: boolean = false;
  buListforNewProduct: boolean = false;
  prodList: boolean = false;
  managementList: boolean = false;
  showDetails: boolean = false;
  toolManagementDetails:any = '';

  @HostListener('click', ['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
    if(event.target.className.indexOf('current-sel-opt') == -1) this.buList = this.prodList = this.managementList = this.popupControls.popupForProductionList = false;    
  }

  @ViewChild('closebutton', { static: false }) closebutton;
  @ViewChild('closebuttonMac', { static: false }) closebuttonMac;
  
  @ViewChild('productlineclosebutton', { static: false }) productclosebutton;
  @ViewChild('toolMgmtModel', { static: false }) toolMgmtModel:ElementRef;
  @ViewChild('errorModel', { static: false }) errorModel:ElementRef;
  
  generateMac: any = "";
  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient,
    private exportService: ExportMacInCsvService,
    private getService:sharedService
  ) { }

  ngOnInit() {
    
    this.getBusinessUnit();
    //this.getProductDetails();
    this.toolManagementDetails = this.fb.group({
      'businessUnit': [null,[Validators.required]],
      'productLineName': [null,[Validators.required]],
      'serial': ['', [Validators.required,Validators.maxLength(15),Validators.pattern(/^[a-zA-Z0-9#]+$/)]],
      'batch': [''],
      'other': [''],
    });
    
  }

  get f() {
    return this.toolManagementDetails.controls;
  }
  get t() { 
    return this.f.serial;
   }
  get g() { 
    return this.f.productLineName;
   }
  get h() { 
    return this.f.productLineName;
   }


  getBusinessUnit(): void {
    this.checkValue=false;
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
       
        console.log("Result data",res);
        res.forEach( item => {
         this.checkValue=true;
         this.articlesdata = item.businessUnit;
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
        }), 
        console.log("List of business unit=>",this.articlesdata);
       
      },
      error => {console.log("After result 2",error)}
  );
  }
  filterForeCasts(args) {
    // this.productRequestForm.value.oui.patchValue(args.target.value, {
    //   onlySelf: true
    // })
    this.toolManagementDetails.value.businessUnit = args.target.value;
    this.toolManagementDetails.value.productLineName=''; 
    this.managementType='';
    this.currentBusinessUnit=args.target.value;
    console.log("Ada Chii",this.currentBusinessUnit);
    this.getProductDetails();
    //this.productLineName = this.productDetails[0];
    this.toolManagementDetails.patchValue({
      productLineName: null
    })
    console.log(this.toolManagementDetails);
    // if(args.target.value ==0 ){
    // this.productRequestForm.value.oui = args.target.value;
    // }else{
    // // this.productRequestForm.value.oui = args.target.value; 
    // this.productRequestForm.value.oui = args.target.options[args.target.selectedIndex].text; 
    // }
    
  }
  filterForeCasts2(args) {
    // this.productRequestForm.value.oui.patchValue(args.target.value, {
    //   onlySelf: true
    // })
    this.toolManagementDetails.value.productLineName = args.target.value;
    // if(args.target.value ==0 ){
    // this.productRequestForm.value.oui = args.target.value;
    // }else{
    // // this.productRequestForm.value.oui = args.target.value; 
    // this.productRequestForm.value.oui = args.target.options[args.target.selectedIndex].text; 
    // }
    console.log(this.toolManagementDetails.value.productLineName);
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool: boolean = false;
    for (var key in this.popupSelectedOption[objName]) {
      if (this.popupSelectedOption[objName].hasOwnProperty(key)) {
        if (this.popupSelectedOption[objName][key] == null || this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined) {
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }
  downloadCSV(){
    this.exportService.downloadFile(this.jsonData, 'jsontocsv');
  }
  toggleDropDownList(type) {
    if (type == 'BU') {
      this.buList = !this.buList;
      this.prodList = false;
    }else if (type == 'NPL') {
      this.buListforNewProduct = !this.buListforNewProduct;
      this.prodList = false;
    }else if(type== 'PL'){
      this.prodList = !this.prodList;
      this.buList = false;
      this.buListforNewProduct =false;
    } else if(type == 'CreateProduct') {
      this.popupControls.popupForProductionList = !this.popupControls.popupForProductionList;
    } else if(type == 'MT') {
      this.managementList = !this.managementList;
    }
  }

  dropdownOptionSelector(event, index, arr, selectItem,currentItemSelected) {
    event.stopPropagation();
    console.log(event, index, arr, selectItem,currentItemSelected)
    console.log(arr, this[arr]);
    let curIndex = null;
    selectItem.forEach((i,v)=>{
      if(i.name == currentItemSelected) {
        curIndex = v;
      }
    });
    this.managementType=selectItem[curIndex].type;
    console.log("current index-->",selectItem[curIndex].type);
    // console.log("current index",curIndex,selectItem[curIndex].type);
    // this[arr].forEach((i) => {
    //   // i.selected = false;
    // console.log("type==>",i.type);
    //     i.selected = true;
    //     this[selectItem] = i.name;
    //     console.log("BOO-->",this[selectItem]);
    //     if (selectItem == 'currentProductItem') {
    //       this.managementType = i.type;
    //       console.log("HOO-->",this.managementType);
    //       this.toolManagementDetails.reset();
    //     } 
    // });
    // console.log(this.managementType);
    // this[list] = false;

    //this.setClientOption();
  }

  // openProductCreation() {
  //   this.toolManagementDetails.value.businessUnit = this.currentBusinessUnit;
  //   this.popupSelectedOption.businessUnit.mainValue = this.newCurrentBusinessUnit;
  // }
  clearForm() {
    this.toolManagementDetails.value.batchCode.patchValue('');
    
  }

  openGenerateMAC(){
    console.log($("#toolMgmtModel"));
    console.log(this.toolMgmtModel, this.errorModel,this.closebutton)
    this.resetErrors();
    this.checkValue=false;
    let param = {
      "batchCode": this.toolManagementDetails.value.batch,
      "businessUnit": this.toolManagementDetails.value.businessUnit,
      "factoryLocation": "Sipcot",
      "otherInfo": this.toolManagementDetails.value.other,
      "productLineName": this.toolManagementDetails.value.productLineName,
      "requestType": this.managementType,
      "serialNumber": this.toolManagementDetails.value.serial,
      "generatedBy":"Prasanna"
    }
    console.log(param);
    this.getService.generateMac(param).subscribe(res => {
      console.log(res);
        this.generatedMacforToolManagement = res.body;
        
        console.log('success model')
      },
      (err) => {
        console.log(err);
        if(err.status==200){
            this.macAddress= err.error.text;
            this.toolManagementDetails.reset();
            this.currentBusinessUnit='';
            this.managementType='';
            this.checkValue=true;
            // this.toolManagementDetails.patchValue({
            //   'serial': "",
            //   'batch': "",
            //   'other': "",
            // })
          
            this.openModel("#toolMgmtModel");
            console.log('err success 200')
        }
        else if(err.status==406 || err.status==400 || err.status==500){
          this.error = err.error.message;
          // this.toolManagementDetails.reset();
          console.log('error model')
          this.openModel('#errorModel');
          this.checkValue=true;
          // setTimeout(()=>{    //<<<---    using ()=> syntax
          //   this.closeModel('#errorModel');
          // }, 3000);
        }else{
          this.error = "Internal Server Error";
          // this.toolManagementDetails.reset();
          console.log('error model')
          this.openModel('#errorModel');
          this.checkValue=true;
          // setTimeout(()=>{    //<<<---    using ()=> syntax
          //   this.closeModel('#errorModel');
          // }, 3000);
        }
      }  
    );
  }

  openModel(modalName) {
    /* console.log(this[modalName],modalName)
    //console.log("modalName=>",modalName,modalName.nativeElement.className)
    modalName.nativeElement.click();
    //modalName.nativeElement.modal('show');
    console.log(modalName.nativeElement.className) */
    $(modalName).modal('show');
    console.log('updated')
  }
  closeModel(modalName) {
    //  this[modalName].nativeElement.className = 'modal hide';
     $(modalName).modal('hide');
  }

//   downLoadFile(data: any, type: string) {
//     let blob = new Blob([data], { type: type});
//     let url = window.URL.createObjectURL(blob);
//     let pwa = window.open(url);
    
//     if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
//         alert( 'Please disable your Pop-up blocker and try again.');
//     }
// }



  downloadMACAddress(): void {
    this.checkValue=false;
    let downloadMacReportList =   {
      "businessUnit": this.toolManagementDetails.value.businessUnit,
      "productLineName": this.toolManagementDetails.value.productLineName
    }
    this.getService.downloadMAC_Address_api(downloadMacReportList).subscribe(res => { 

      // this.exportService.downloadFile(res, 'jsontocsv');

      this.checkValue=true;

    // let blob = new Blob([res], { type: 'text/json; charset=utf-8'});
    // let url = window.URL.createObjectURL(blob);
    // let pwa = window.open(url);
    // window.location.href = res.url;
    // fileSaver.saveAs(blob, 'employees.json');
    // if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
    //     alert( 'Please disable your Pop-up blocker and try again.');
    // }
      // let output = res.body;

      let blob:any = new Blob([res], { type: 'text/json; charset=utf-8' });
      // let dwldLink = document.createElement("a");
      const url= window.URL.createObjectURL(blob);
      
      // dwldLink.setAttribute("href", res.url );
      window.location.href = res.url;
      // dwldLink.setAttribute("download", "MAC Address List" + ".csv");
      // dwldLink.style.visibility = "hidden";
      // document.body.appendChild(dwldLink);
      // dwldLink.click();
      // document.body.removeChild(dwldLink);
      

      // let csvData = this.ConvertToCSV(res, ['name','mac_address']);
      // console.log(csvData)
      // let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
      // let dwldLink = document.createElement("a");
      // let url = URL.createObjectURL(blob);
      // let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
      // if (isSafariBrowser) {  //if Safari open in new window to save file with random filename.
      //     dwldLink.setAttribute("target", "_blank");
      // }
      // dwldLink.setAttribute("href", url);
      // dwldLink.setAttribute("download", "MAC Address List" + ".csv");
      // dwldLink.style.visibility = "hidden";
      // document.body.appendChild(dwldLink);
      // dwldLink.click();
      // document.body.removeChild(dwldLink);
    },
    (err) => {
      console.log(err);
      if(err.status==200){
          this.checkValue=true;
          console.log('err success 200')
      }
      else if(err.status==406 || err.status==400 || err.status==500){
        this.error = "Error in downloading";
        // this.toolManagementDetails.reset();
        console.log('error model')
        this.openModel('#errorModel');
        this.checkValue=true;

      }else{
        this.error = "Internal Server Error";
        // this.toolManagementDetails.reset();
        console.log('error model')
        this.openModel('#errorModel');
        this.checkValue=true;
      }
    } 
    )
  }

  sendBusinessData() {
    console.log("Data to Send",this.popupSelectedOption.businessUnit);
    this.closebutton.nativeElement.click();
  }

  getProductDetails(): void {
    console.log(this.toolManagementDetails.value.businessUnit);
    // let BussinessUnitList =  this.currentBusinessUnit;
    console.log("Ada Ponga da",this.currentBusinessUnit);
    this.productDetails = [];
    this.checkValue=false;
    this.getService.getProductDetails_api(this.currentBusinessUnit).subscribe(
      (res: any[]) => {
        this.checkValue=true;
        console.log("response prod=>",res)
        res.forEach( item => {
          console.log(item.productLineName);
          this.productDetails.push({
            name: item.productLineName,
            selected: false,
            disabled: false,
            type:item.requestType,
            businessUnit:item.businessUnit
          })
        })
        console.log("updated prod list=>",this.productDetails);
       
      },
      (err) => {
        this.productDetails = err;
      });
  }

  copyMacAddress() {
    var copyText = document.getElementsByClassName("mac-address")[0];
    console.log("Copy Text 1-->",copyText);
    var textArea = document.createElement("textarea");
    console.log("Copy Text 3-->",textArea);
    textArea.value = copyText.textContent;
    console.log("Copy Text 4-->",textArea.value);
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand("Copy");
    textArea.remove();
  }

  enableDisableGenMacButton(){
    //return this.currentBusinessUnit && this.currentProductItem && 
    console.log(this.toolManagementDetails.status != 'VALID',this.toolManagementDetails)
    return this.toolManagementDetails.status != 'VALID';
  }

}

