import { Component } from '@angular/core';
import { AuthService } from './auth/auth.service'
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';
import { sharedService } from './service/shared-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MAC-ALLOCATOR';
  userRole:any='';
  constructor(
    private router:Router,
    private AuthService:AuthService,
    private DataService:sharedService
    ){
    sessionStorage.setItem('USER_NAME','Test User');
    sessionStorage.setItem('USER_ROLE','ADMIN');
    this.getLoginDetails();
  }

   
  getLoginDetails() {
    if(sessionStorage.getItem('USER_NAME')){
      this.AuthService.isLoggedIn = true;
    } else {
      this.AuthService.isLoggedIn = false;
    }
    if(sessionStorage.getItem('USER_ROLE') == 'ADMIN'){
      this.AuthService.isAdmin = true;
      this.AuthService.userRole=sessionStorage.getItem('USER_ROLE');
      this.AuthService.userName=sessionStorage.getItem('USER_NAME');
      console.log("User Role-->",this.AuthService.userName);
      
    } else if(sessionStorage.getItem('USER_ROLE') == 'USER'){
      this.AuthService.isAdmin = false;
      this.AuthService.userRole= sessionStorage.getItem('USER_ROLE');
      this.AuthService.userName=sessionStorage.getItem('USER_NAME');
      console.log("User Role-->",this.AuthService.userName);
    }
  }
}
