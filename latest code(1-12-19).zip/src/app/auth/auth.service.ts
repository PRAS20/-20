import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, catchError, tap, delay } from 'rxjs/operators';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpParams,HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn:boolean = true;
  isAdmin:boolean = false;
  isPageAvailable:boolean = true;
  userRole:any='';
  userName:any='';




  constructor(
    private router:Router,
    private http: HttpClient
  ) {
    
   }






  login(): Observable<boolean> {
    return of(true).pipe(
      delay(1000),
      tap(val => this.isLoggedIn = true)
    );
  }

  logout(): void {
    console.log('logout')
    this.isLoggedIn = false;
    console.log('logout',this.isLoggedIn);
    this.router.navigate(['not_authorized']);
    sessionStorage.clear()
  }
}
