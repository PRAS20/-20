import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';
declare var $: any;

@Component({
  selector: 'app-oui-statistics',
  templateUrl: './oui-statistics.component.html',
  styleUrls: ['./oui-statistics.component.css']
})
export class OuiStatisticsComponent implements OnInit {

  ouiDetails: any[] = [];
  articles: any[] = [];
  articlesdata: any[] = [];
  productDetails: any[] = [];
  generateReportForm: any = '';
  currentBusinessUnit: any = "";
  checkValue:boolean=true;
  error: any = '';
  success: any = '';

  private resetErrors() {
    this.success = '';
    this.error = '';
  }
  constructor(
    private fb: FormBuilder,
    private getService: sharedService
  ) { }

  ngOnInit() {
    this.getBusinessUnit();
    this.getOUIDetails();

    this.generateReportForm = this.fb.group({
      'businessUnit': [null, [Validators.required]],
      'productLineName': [null, [Validators.required]],
    });

  }
  get f() {
    return this.generateReportForm.controls;
  }
  filterForeCastsProduct(args) {
    this.generateReportForm.value.businessUnit = args.target.value;
    this.generateReportForm.value.productLineName = '';
    this.currentBusinessUnit = args.target.value;
    this.getProductDetails();
    this.generateReportForm.patchValue({
      productLineName: null
    })

    console.log("Business Data",this.generateReportForm.value.businessUnit);
    console.log("Business Data",this.currentBusinessUnit);
  }

  getProductDetails(): void {
    this.productDetails = [];
    this.checkValue=false;
    this.getService.getProductDetails_api(this.currentBusinessUnit).subscribe(
      (res: any[]) => {
        res.forEach(item => {
          this.checkValue=true;
          this.productDetails.push({
            name: item.productLineName,
            selected: false,
            disabled: false
          })
        })
      },
      (err) => {
        this.productDetails = err;
      });
  }

  getOUIDetails(): void {
    this.checkValue=false;
    this.getService.getOUIDetails_api().subscribe(
      (res: any[]) => {
        this.checkValue=true;
        this.ouiDetails = res;
        console.log(this.ouiDetails);
      },
      (err) => {
        this.ouiDetails = err;
      });
  }
  filterForeCasts(args) {
    // this.productRequestForm.value.oui.patchValue(args.target.value, {
    //   onlySelf: true
    // })
    this.generateReportForm.value.businessUnit = args.target.value;
    // if(args.target.value ==0 ){
    // this.productRequestForm.value.oui = args.target.value;
    // }else{
    // // this.productRequestForm.value.oui = args.target.value; 
    // this.productRequestForm.value.oui = args.target.options[args.target.selectedIndex].text; 
    // }
    console.log(this.generateReportForm.value.businessUnit);
  }


  getBusinessUnit(): void {
    this.checkValue=false;
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        this.checkValue=true;
        this.articlesdata = res;

        console.log("List of business unit=>", this.articlesdata);

      },
      (err) => {
        this.articles = err;
      });
  }
  openModel(modalName) {
    $(modalName).modal('show');
  }
  closeModel(modalName) {
     $(modalName).modal('hide');
  }
  
  downloadMACAddress(): void {
    this.checkValue=false;

    let productLineList:any =  {
      "businessUnit": this.currentBusinessUnit,
      "productLineName": this.generateReportForm.value.productLineName
    }
  
    this.getService.downloadProductLine_MACAddress_api(productLineList).subscribe(res => { 

      this.checkValue=true;

      let blob:any = new Blob([res], { type: 'text/json; charset=utf-8' });
      // let dwldLink = document.createElement("a");
      const url= window.URL.createObjectURL(blob);
      
      // dwldLink.setAttribute("href", res.url );
      window.location.href = res.url;

    },
    (err) => {
      console.log(err);
      if(err.status==200){
          this.checkValue=true;
          console.log('err success 200')
      }
      else if(err.status==406 || err.status==400 || err.status==500){
        this.error = "Error in downloading";
        // this.toolManagementDetails.reset();
        console.log('error model')
        this.openModel('#errorModel');
        this.checkValue=true;

      }else{
        this.error = "Internal Server Error";
        // this.toolManagementDetails.reset();
        console.log('error model')
        this.openModel('#errorModel');
        this.checkValue=true;
      }
    } 
    ),
    error => console.log('Error downloading the file'),
    () => console.info('File downloaded successfully');
  }

}
