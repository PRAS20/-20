import { Component,Input,OnChanges,SimpleChanges,SimpleChange, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { sharedService } from './../service/shared-service.service';
import { HttpErrorResponse } from '@angular/common/http';

declare var $: any;

@Component({
  selector: 'app-client-generator',
  templateUrl: './client-generator.component.html',
  styleUrls: ['./../app.component.css','./client-generator.component.css']
})
export class ClientGeneratorComponent implements OnInit  {

  clientDetails: any [] = [];
  productDetails: any[] = [];
  clientNamePop:boolean = false;
  productNamePop:boolean = false;
  selectedClientOption:string = "Select a Client";
  selectedProductOption:string = "";
  clientRegistration:any;
  clientRegistrationValue:any;
  requestTypeDetails: any[] = [];
  articles: any[] = [];
  currentBusinessUnit: any = "";
  error:any = '';
  success:any = '';
  checkValue:boolean=true;
  private resetErrors(){
    this.success = '';
    this.error   = '';
  }
  
  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private http: HttpClient,
    private getService:sharedService,
    private formBuilder: FormBuilder,
    private router: Router
    ){ }
 

    
  
  ngOnInit() {
    this.getBusinessUnit();
    this.getClientDetails();
    // this.getProductDetails();
    this.clientRegistrationValue = this.fb.group({
      'businessUnit':[null, [Validators.required]],
      'clientName':['',[Validators.required,Validators.pattern(/^[a-zA-Z0-9]+$/)]],
      'productLineName': [null, [Validators.required]],
    });
  }

  get f() {
    return this.clientRegistrationValue.controls;
  }
  filterForeCastsProduct(args){
    this.clientRegistrationValue.value.businessUnit = args.target.value;
    this.clientRegistrationValue.value.productLineName=''; 
    this.currentBusinessUnit=args.target.value;
    this.getProductDetails();
    this.clientRegistrationValue.patchValue({
      productLineName: null
    })
  }

  filterForeCasts(args) {
    // this.productRequestForm.value.oui.patchValue(args.target.value, {
    //   onlySelf: true
    // })
    this.clientRegistrationValue.value.productLineName = args.target.value;
    // if(args.target.value ==0 ){
    // this.productRequestForm.value.oui = args.target.value;
    // }else{
    // // this.productRequestForm.value.oui = args.target.value; 
    // this.productRequestForm.value.oui = args.target.options[args.target.selectedIndex].text; 
    // }
    console.log(this.clientRegistrationValue.value.productLineName);
  }
  sendClientData(){
    this.resetErrors();
    this.checkValue=false;
    let data = {
      "businessUnit":this.clientRegistrationValue.value.businessUnit,
      "clientName": this.clientRegistrationValue.value.clientName,
      "productLineName": this.clientRegistrationValue.value.productLineName,
      "requestedBy": "Prasanna",
    }
    this.getService.createClient(data).subscribe(res => { 
      console.log(res.body)
      let output = res.body;
     },
     (err) => {
       console.log(err);
      if(err.status==200){
        this.checkValue=true;
        this.success = err.error.text;
        this.clientRegistrationValue.reset();
        this.closeModel("#clientNameModal");
        this.openModel("#approveModel");
      }else if(err.status==400 || err.status==406 || err.status==500){
        this.checkValue=true;
        this.error = err.error.message;
      }
      else{
        this.checkValue=true;
        this.error = err.error.message;
      }
    }
    );  
  }

  
  getBusinessUnit(): void {
    this.checkValue=false;
    this.getService.getBussinessUnit_api().subscribe(
      (res: any[]) => {
        res.forEach( item => {
          this.checkValue=true;
          console.log(item.businessUnit);
          this.articles.push({
            name: item.businessUnit,
            selected: false,
            disabled: false
          })
        })
        console.log(this.articles);
      },
      (err) => {
        this.articles = err;
      });
  }
  resetform(){
    this.clientRegistrationValue.reset();
    this.closeModel("#clientNameModal");
  }
  copyMacAddress(clientToken){
    
    var copyText = clientToken;
    console.log("Client Token-->",copyText);
    var textArea = document.createElement("textarea");
    console.log("Client Token 2-->",textArea);
    textArea.value = copyText;
    console.log("Client Token 3-->",textArea.value);
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand("Copy");
    textArea.remove();

  }
  getClientDetails(): void {
    this.checkValue=false;
    this.getService.getClientDetails_api().subscribe(
      (res: any[]) => {
        this.checkValue=true;
        this.clientDetails = res;
        console.log(this.clientDetails);
      },
      (err) => {
        this.clientDetails = err;
      });
  }

  getProductDetails(): void {
    this.productDetails = [];
    this.checkValue=false;
    this.getService.getProductDetails_api(this.currentBusinessUnit).subscribe(
      (res: any[]) => {
        res.forEach( item => {
          this.checkValue=true;
          console.log(item.requestType);
          if(item.requestType !="SELFMANAGED"){
            this.productDetails.push({
              name: item.productLineName,
              selected: false,
              disabled: false
            })
          }
          
        })
      },
      (err) => {
        this.productDetails = err;
      }); 
  }

  toggleClientPop() {
    this.productNamePop = false;
    this.clientNamePop = !this.clientNamePop;
   
  }


  clientOptionSelector(event,index) {
    event.stopPropagation();
    this.clientDetails.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedClientOption = i.name;
      }
    });
    this.clientNamePop = false;
    //this.setClientOption();
  }

  productOptionSelector(event,index) {
    event.stopPropagation();
    this.productDetails.forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.selectedProductOption = i.name;
      }
    });
    this.productNamePop = false;
    //this.setClientOption();
  }
  submitData(){
    this.openModel("#clientNameModal");
  }
  openModel(modalName) {
    $(modalName).modal('show');
    console.log('updated')
  }
  closeModel(modalName) {
     $(modalName).modal('hide');
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    console.log(event,index,arr,selection,showVar,unitName);
    console.log(this[arr])
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
    if(unitName == 'productLine') {
      this.clientRegistrationValue.controls['productLineName'].setValue( this.popupSelectedOption.productLine.mainValue);
    }
  }


  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }



}
