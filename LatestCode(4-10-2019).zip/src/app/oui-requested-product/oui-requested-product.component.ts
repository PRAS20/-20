import { Component, OnInit, ElementRef, HostListener, ViewChild } from '@angular/core';

@Component({
  selector: 'app-oui-requested-product',
  templateUrl: './oui-requested-product.component.html',
  styleUrls: ['./../app.component.css', '../dashboard/dashboard.component.css','./../generate-mac/generate-mac.component.css','./oui-requested-product.component.css']
})
export class OuiRequestedProductComponent implements OnInit {

  popupControls:any = {
    popupForBusinessUnit:false,
    popupForProductUnit:false
  }

  popupSelectedOption:any = {
    businessUnit: {
      mainValue: "",
      prodName: "",
      macOUI: ""
    },
    productLine: {
      mainValue: "",
      clientName:""
    }
  }

  selectedItem:any = "";


  requestedProductNames:any = [
    {
      productName: "Apple",
      raisedBy: "Elavarasan",
      businessUnit: "Android",
      macOUI: "OUI"
    },
    {
      productName: "Ball",
      raisedBy: "Prasanna",
      businessUnit: "Android",
      macOUI: "OUI"
    },
    {
      productName: "Cat",
      raisedBy: "Vinoth",
      businessUnit: "iPhone",
      macOUI: "OUI"
    },
    {
      productName: "Dog",
      raisedBy: "Prasanna",
      businessUnit: "Android",
      macOUI: "OUI"
    },
    {
      productName: "Energy",
      raisedBy: "Vishnu",
      businessUnit: "Windows",
      macOUI: "OUI"
    },
    {
      productName: "Flu",
      raisedBy: "Elavarasan",
      businessUnit: "iPhone",
      macOUI: "OUI"
    },
    {
      productName: "Green",
      raisedBy: "Sukanya",
      businessUnit: "Windows",
      macOUI: "OUI"
    },
    {
      productName: "Haryana",
      raisedBy: "Prasanna",
      businessUnit: "Windows",
      macOUI: "OUI"
    }
  ]

 
  popupBusinessLineData:any = [
    {
      name: "iPhone",
      selected: false,
      disabled: false
    },
    {
      name: "Android",
      selected: false,
      disabled: false
    },
    {
      name: "Windows",
      selected: false,
      disabled: false
    }
  ]


  @HostListener('click',['$event'])
  clickInside(event) {
    //console.log('he,lo',event);
    //if(event.target.className.indexOf('current-sel-opt') == -1) this.clientNamePop = this.productNamePop = this.popupControls.popupForBusinessUnit = this.popupControls.popupForProductUnit = false;    
  }

  @ViewChild('closebutton',{static: false}) closebutton;
  @ViewChild('productlineclosebutton',{static: false}) productclosebutton;

  constructor(
    
    ){

      
     }

  ngOnInit() {

  }

  toggleBussinessPop(objName) {
    this.popupControls[objName] = !this.popupControls[objName];    
  }

  disablePopupSubmitButton(objName) {
    //console.log('diableing');
    var bool:boolean = false;
    for(var key in this.popupSelectedOption[objName]) {
      if(this.popupSelectedOption[objName].hasOwnProperty(key)){
        //console.log(key,this.popupSelectedOption[objName][key])
        if(this.popupSelectedOption[objName][key] == null ||this.popupSelectedOption[objName][key] == "" || this.popupSelectedOption[objName][key] == undefined ){
          bool = true;
          break;
        }
      }
    }
    //console.log("bool",bool,this.popupSelectedOption[objName])
    return bool;
  }

  publishData() {
    console.log("Published..!");
  }

  editRecord(item) {
    console.log("item=>", item);
    for(let ind=0;ind<this.popupBusinessLineData.length;ind++) {
      if(this.popupBusinessLineData[ind].name == item.businessUnit) {
        this.popupBusinessLineData[ind].selected = true;
        this.popupSelectedOption.businessUnit.mainValue = item.businessUnit;
        this.popupSelectedOption.businessUnit.prodName = item.productName;
        this.popupSelectedOption.businessUnit.macOUI = item.macOUI;
      } else {
        this.popupBusinessLineData[ind].selected = false;
      }
    }

    this.selectedItem = item;
    
  }

  businessOptionSelector(event,index,arr,selection,showVar,unitName) {
    event.stopPropagation();
    this[arr].forEach((i,v)=>{
      i.selected = false;
      if(v == index) {
        i.selected = true;
        this.popupSelectedOption[unitName][selection] = i.name;
      }
    });
    this.popupControls[showVar] = false;
  }

  sendProductName() {
    console.log(this.popupSelectedOption.businessUnit);

    for(let ind = 0; ind < this.requestedProductNames.length; ind++) {
        if(this.requestedProductNames[ind].productName == this.selectedItem.productName) {
          this.requestedProductNames[ind].businessUnit = this.popupSelectedOption.businessUnit.mainValue;
          this.requestedProductNames[ind].productName = this.popupSelectedOption.businessUnit.prodName;
          this.requestedProductNames[ind].macOUI = this.popupSelectedOption.businessUnit.macOUI;
          break;
        }
    }
    this.closebutton.nativeElement.click();
  }

}
