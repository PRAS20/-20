<?php
	error_reporting(true);
    include_once("../Models/app-config.php");
    include_once('../Models/task.php');
	$postData = json_decode(file_get_contents("php://input"), true);
    $projData = $postData['data'];
	$result = [];
	if(!isset($projData['user_id']) || !isset($projData['role']) || !isset($projData['status'])){
        $result['statusMsg'] = 'Inadequate project details!';
		$result['status'] = false;
    }else{
		$taskObj = new task();
		$result['data'] = $taskObj->getHistory($projData['user_id'],$projData['role'],$projData['status']);
		$result['statusMsg'] = 'Project created successfully!';
		$result['status'] = true;
		echo json_encode($result['data']);
		/*
		echo "<pre>";
		print_r($result);
		*/
	} 
    exit;
?>