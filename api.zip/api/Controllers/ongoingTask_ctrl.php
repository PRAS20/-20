<?php
	error_reporting(true);
    include_once("../Models/app-config.php");
    include_once('../Models/task.php');
	$postData = json_decode(file_get_contents("php://input"), true);
    $projData = $postData['data'];
	$result = [];
	if(!isset($projData['user_id']) || !isset($projData['role'])){
        $result['statusMsg'] = 'Inadequate project details!';
		$result['status'] = false;
    }else{
		$taskObj = new task();
		$result['data'] = $taskObj->getOngoingTasks($projData['user_id'],$projData['role']);
		$result['status'] = true;
	}
	echo json_encode($result);
    exit;
?>