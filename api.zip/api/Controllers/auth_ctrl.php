<?php
	error_reporting(true);
    include_once('../Models/auth.php');
	$postData = json_decode(file_get_contents("php://input"), true);
    $projData = $postData['data'];
	
	/*
	//For Requestor
	$projData['user_name'] = 'req';
	$projData['password'] = 'req';
	
	//For Admin
	$projData['user_name'] = 'admin';
	$projData['password'] = 'adminuser';
	
	//For SMO
	$projData['user_name'] = 'smo';
	$projData['password'] = 'smo';
	
	*/
	
    $result = [];
	if(!isset($projData['user_name']) && !isset($projData['user_password'])){
        $result['statusMsg'] = 'Inadequate project details';
		$result['status'] = false;
    }else{
		$authObj = new authentication();
		$result['data'] = $authObj->getAuthenticate($projData['user_name'],$projData['user_password']);
	}
	echo json_encode($result);
	//echo "<pre>";
	//print_r($result);
    exit;
?>