<?php
	error_reporting(true);
    include_once("../Models/app-config.php");
    include_once('../Models/task.php');
	$postData = json_decode(file_get_contents("php://input"), true);
    $projData = $postData['data'];
	//echo "test data printed here" $projData;
	
	//Test Data
	//$projData['user_id'] = 'NDF_1';
	//$projData['pending_with'] = 'Requestor';
	//$projData['proj_id'] = 'P_54';
	$result = [];
	
	if(!isset($projData['proj_id'])){
        $result['statusMsg'] = 'Inadequate project details!';
		$result['status'] = false;
    }else{
		$taskObj = new task();
		$result['data'] = $taskObj->Selected_Task($projData['proj_id']);
		$result['statusMsg'] = 'Project selected successfully!';
		$result['status'] = true;
		echo json_encode($result);
		
		
		/* echo "<pre>";
		print_r($result); */
		
	} 
    exit;
?>