<?php
	error_reporting(true);
    include_once("../Models/app-config.php");
    include_once('../Models/task.php');

	$postData = json_decode(file_get_contents("php://input"), true);

    $projData = $postData['data'];
    $result = [];
				
	//Test Data
	/* $projData['user_id'] = 'NDF_1';
	$projData['taskArr'] = [];
	$taskObj = [];
	$taskObj['project_id'] = '';
	$taskObj['project_name'] = 'Test Project 50';
	$taskObj['catalogue_type_id'] = 1;
	$taskObj['catalogue_type_name'] = 'Website Build Service Catalog';
	$taskObj['task_type_id'] = 1;
	$taskObj['task_type_name'] = 'Static Website Build-Low';
	$taskObj['task_type_description'] = "Number of Templates: 1-2, Number of content Pages: 10-15";
	$taskObj['price'] = 100;
	$taskObj['effort'] = 20;
	$taskObj['start_date'] = '2019-02-12';
	$taskObj['end_date'] = '2019-02-12';
	$taskObj['task_status'] = "open";
	$taskObj['artifacts_link'] = "artifacts_link_value";
	$taskObj['pending_with'] = "SMO";
	array_push($projData['taskArr'],$taskObj); */
	
	
	if(!isset($projData['user_id']) && $projData['taskArr']){
        $result['statusMsg'] = 'Inadequate project details!';
		$result['status'] = false;
    }else{
		$taskObj = new task();
		$result['data'] = $taskObj->createTask($projData['user_id'],$projData['taskArr']);
		$result['statusMsg'] = 'Project created successfully!';
		$result['status'] = true;
		echo json_encode($result);
	}
	
	//echo "<pre>";
	//print_r($result);
    exit;
?>