<?php
	error_reporting(true);
    include_once("../Models/app-config.php");
    include_once('../Models/task.php');
	$postData = json_decode(file_get_contents("php://input"), true);
    $projData = $postData['data'];
	$result = [];
    $taskObj = new task();
    $result['data'] = $taskObj->getAllCataloguesList();
	$result['status'] = true;
	echo json_encode($result);
	/* echo "<pre>";
	print_r($result); */
    exit;
?>