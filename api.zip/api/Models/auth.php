<?php
	error_reporting(true);
    include_once("../Models/app-config.php");
    include_once('../Models/db.php');
	include_once('../ldap/ldap.php');
	class authentication{
		public $errorLog;
        public function authentication(){
            $this->errorLog = [];
        }
		public function getAuthenticate($userName, $password){
			$userLoggedArr = [];
			
			//Check For Admin User
			if(($userName == 'admin') && ($password == 'adminuser')){
				$userLoggedArr['name'] = 'Admin';
				$userLoggedArr['email'] = '';
				$userLoggedArr['role_id'] = 0;
				$userLoggedArr['role_name'] ='Admin';
				$userLoggedArr['status'] = true;
				$userLoggedArr['statusMsg'] = "Admin Credentials";
				return $userLoggedArr;
			}
			
			//Check For External User
			$userLoggedArr = $this->CheckForExternelUsers($userName, $password);
			if(isset($userLoggedArr['user_id'])){
				return $userLoggedArr;
			}else{
			
				//For Cognizant Users
				$userLoggedArr = $this->CheckForInternalUsers($userName, $password);
				
				//For Non Cognizant Users
				//$userLoggedArr = $this->NonCogInternalUsers($userName, $password);
				
				if(!isset($userLoggedArr['user_id'])){
					$userLoggedArr['status'] = false;
					$userLoggedArr['statusMsg'] = "Invalid Credentials";
				}
				return $userLoggedArr;
			}
		}
		
		public function CheckForExternelUsers($userName, $password){
			$externalUserArr = [];
			try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL CheckForExternelUsers('" . $userName . "','" . $password . "');";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$externalUserArr['user_id'] = $row['user_id'];
					$externalUserArr['name'] = $row['first_name']." ".$row['last_name'];
					$externalUserArr['email'] = $row['email'];
					$externalUserArr['role_id'] = $row['role_id'];
					$externalUserArr['role_name'] =$row['role_name'];
					$externalUserArr['status'] = true;
					$externalUserArr['statusMsg'] = "Authenticate success";
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in CheckForExternelUsers!';
            }
			return $externalUserArr;
		}
		
		public function CheckForInternalUsers($username, $password){
			//Check For Internal User
			$InternalUserArr = [];
			try{
				$ldaphost = '10.242.25.10';//$ldaphost = 'ldap://cts.com';
				$ldaprdn  = "cts\\".$username; 
				$ldappass = $password; 
				set_time_limit(0);
				$ldapconn = ldap_connect($ldaphost);
				if ($ldapconn) {
					$ldapbind = @ldap_bind($ldapconn, $ldaprdn, $ldappass);
					if ($ldapbind) {
						$filter = 'sAMAccountName='.$username;
						$basedn = "OU=Cognizant,DC=cts,DC=com";
						$result = ldap_search($ldapconn, $basedn, $filter) or die ("Search error.");
						$entries = ldap_get_entries($ldapconn, $result);
						
						$name = str_replace(' (Cognizant)', '', $entries[0]['displayname'][0]);
						$mailId = $entries[0]['mail'][0];
						$id = $username;
						$InternalUserArr['user_id'] = $id;
						$InternalUserArr['name'] = $name;
						$InternalUserArr['email'] = $mailId;
						$InternalUserArr['status'] = true;
						$InternalUserArr['statusMsg'] = "Authenticate success";
						
						//check for login role_id and role_name
						
						$roleData = [];
						$roleData = $this->checkInternalUserRole($id);
						if(isset($roleData[0]['role_id']) && isset($roleData[0]['role_name'])){
							$InternalUserArr['role_id'] = $roleData[0]['role_id'];
							$InternalUserArr['role_name'] = $roleData[0]['role_name'];
						}else{
							$InternalUserArr['role_id'] = 5;
							$InternalUserArr['role_name'] = "Developer";
						}
					}
				}
			}
			catch(Exception $e){
				$this->errorLog[] = 'Exception thrown in CheckForInternalUsers!';
			}
			return $InternalUserArr;
		}
		
		public function checkInternalUserRole($user_id){
			$roleArr = [];
			try{
				$externalUserArr = [];
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL checkInternalUserRole('" . $user_id . "');";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$roleArr[] = $row;
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in checkInternalUserRole!';
            }
			return $roleArr;
		}
		
		public function NonCogInternalUsers($userName, $password){
			$internalUserArr = [];
			try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL orgInternalUsers('" . $userName . "','" . $password . "');";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
						
					$internalUserArr['user_id'] = $row['user_id'];
					$internalUserArr['name'] = $row['first_name']." ".$row['last_name'];;
					$internalUserArr['email'] = $row['email'];
					$internalUserArr['role_id'] = $row['role_id'];
					$internalUserArr['role_name'] =$row['role_name'];
					$internalUserArr['status'] = true;
					$internalUserArr['statusMsg'] = "Authenticate success";
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in NonCogInternalUsers!';
            }
			return $internalUserArr;
		}
	}
?>


