<?php
	error_reporting(true);
    include_once("../app-config.php");
    include_once('../Models/project.php');
	$postData = json_decode(file_get_contents("php://input"), true);
    $projData = $postData['data'];
	if(isset($projData['username']) && isset($projData['password'])){
		if($projData['username'] == 'guest' && $projData['password'] == 'cognizant@123'){
			$projData['username'] = 251636;
			$projData['password'] = 'jan-2019';
		}
		$assocId = intval($projData['username']);
        $authorizedUserObj = new Project();
        $authorizedUserStatus = $authorizedUserObj->checkAuthorizedUser($assocId);
		
		if($authorizedUserStatus['authStatus'] == false){
			$result['status'] = false;
			$result['statusMsg'] = "Not an authorized user. Please buy licence to use this application";
			echo json_encode($result);
			exit;
		}
		$existingSession = false;
		$projectId = null;
		$projectId = $authorizedUserStatus['projectId'];
		
		if($projectId != 'DF'){
			$maxCount = $authorizedUserObj->getMaxLicenceUseCount($projectId);
			if($maxCount > 0){
				$existingstatus = $authorizedUserObj->checkForExistingSession($projectId);
				if($existingstatus['count'] > 0){
					if($existingstatus['count'] == $maxCount){
						$result['status'] = false;
						$result['statusMsg'] = "Maximum login limit reached.";
						$result['maxusers'] = $existingstatus['arr'];
						echo json_encode($result);
						exit;
					}
				}
			}else{
				$result['status'] = false;
				$result['statusMsg'] = "Licence expired for Project Id ".$projectId.". Please buy it.";
				echo json_encode($result);
				exit;
			}
		}
		
		$username=$projData['username'];
		$password=$projData['password']; 
		$ldaphost = '10.242.25.10';//$ldaphost = 'ldap://cts.com';
		$ldaprdn  = "cts\\".$username; 
		$ldappass = $password; 
		set_time_limit(0);
		$ldapconn = ldap_connect($ldaphost);
		if ($ldapconn) {
			$ldapbind = @ldap_bind($ldapconn, $ldaprdn, $ldappass);
			if ($ldapbind) {
				$filter = 'sAMAccountName='.$username;
				$basedn = "OU=Cognizant,DC=cts,DC=com";
				$result = ldap_search($ldapconn, $basedn, $filter) or die ("Search error.");
				$entries = ldap_get_entries($ldapconn, $result);
				$result = null;
				$name = str_replace(' (Cognizant)', '', $entries[0]['displayname'][0]);
				$mailId = $entries[0]['mail'][0];
				$id = $username;
				$result['status'] = true;
				$result['ExistingSession'] = $existingSession;
				$result['userProjectId'] = $projectId;
				$result['mailId'] = $mailId;
				$result['name'] = $name;
				
				$loginStatus = $authorizedUserObj->loginUpdate($username,$projectId);
				$result['id'] = $id;
				
				$result['statusMsg'] = "Authenticate success";
				echo json_encode($result);	
				exit;
			}else{
				$result['status'] = false;
				$result['statusMsg'] = "Login failed. Please check the credentials";
				echo json_encode($result);
				exit;
			}
		}
	}
	$result = null;
	$result['status'] = false;
	$result['statusMsg'] = "Mandatory fields are missing. Please fill it";
	echo json_encode($result);
	exit;
?>


