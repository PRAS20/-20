<?php
    // header("Access-Control-Allow-Origin: http://digifactory.cognizant.com:3000");
    session_start();
	$GLOBALS['appPath'] = str_replace("\\", "/",dirname( dirname(getcwd())));
?>