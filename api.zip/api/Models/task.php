<?php
	//error_reporting(true);
	error_reporting(E_ALL);
//ini_set('display_errors', 1);
	
    include_once('db.php');
    class task{
        public $errorLog;
        public function task(){
            $this->errorLog = [];
        }
		public function getAllCatalogues(){
			$catalogueTypeArr = [];
            try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL getAllCatalogues();";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$catalogueTypeArr[] = $row;
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in getAllCatalogues!';
            }
            return $catalogueTypeArr;
        }
		public function fetchCatalogueList($tableName){
			$catTypeList = [];
			try{
				$db = new Db('digifactory', 'digiserv_2019');
				$conn = $db->establishConnection();
				$selQuery = "select * from ".$tableName;
				$res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$row['checked'] = false;
					$row['task_type_name'] = $row['task_name'];
					$row['start_date'] = '';
					$row['end_date'] = '';
					$row['effort'] = 0;
					$row['artifacts_link'] = '';
					$row['pending_with'] = 'SMO';
					$row['requesterComments'] = '';
					$row['approverComments'] = '';
					$row['task_status'] = 'open';
					
					$catTypeList[] = $row;
				}	
				mysqli_close($conn);
			}
			catch(Exception $e){
				$this->errorLog[] = 'Exception thrown in getAllCataloguesList!';
			}
			return $catTypeList;
		}
		
		public function getAllCataloguesList(){
			$catalogueTypeArr = [];
			$catalogueObj = [];
			$catalogueTypeArr = $this->getAllCatalogues();
			$catalogueObj['catalogue_list'] = $catalogueTypeArr;
			$catalogueTypeArrList = [];
			foreach($catalogueTypeArr as $item){
				$table_name = $item['table_name'];
				$catalogue_name = $item['catalogue_name'];
				$tempList = $this->fetchCatalogueList($table_name);
				for($x=0;$x < count($tempList);$x++){
					$tempList[$x]['catalogue_name'] = $item['catalogue_name'];
					array_push($catalogueTypeArrList,$tempList[$x]);
				}
			}
			$catalogueObj['catalogue_list_items'] = $catalogueTypeArrList;
			return $catalogueObj;
		}
		
		public function Selected_Task($proj_id){
			$taskArr = [];
			try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL Selected_Task('" . $proj_id . "');";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$row['checked'] = false;
					$row['task_type_name'] = $row['task_name'];
					$row['requesterComments'] = '';
					$row['approverComments'] = '';
					$taskArr[] = $row;
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in Requestor_Pending_Tasks!';
            }
			return $taskArr;
		}
		public function getMyTasks($u_id,$role){
			$myTaskArr = [];
            try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL MyTask(
					'" . $u_id ."',
					'" . $role ."'
				);";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$myTaskArr[] = $row;
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in getMyTasks!';
            }
            return $myTaskArr;
        }
		public function Pending_Tasks($u_id,$role){
			$pendingTaskArr = [];
            try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                $selQuery = "CALL Pending_Task(
					'" . $u_id ."',
					'" . $role ."'
				);";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					
					$pendingTaskArr[] = $row;
                }	
                mysqli_close($conn);
            }
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in getAllCatalogues!';
            }
            return $pendingTaskArr;
        }
		
		public function getHistory($u_id,$role,$status){
			$getHistoryArr = [];
            try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                
				$selQuery = "CALL History('" . $u_id . "','" . $role . "','" . $status . "');";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$getHistoryArr[] = $row;
                }	
                mysqli_close($conn);
			}
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in getHistory!';
            }
            return $getHistoryArr;
        }
		
		public function getOngoingTasks($u_id,$role){
			$getOngoingArr = [];
            try{
                $db = new Db('digifactory', 'digiserv_2019');
                $conn = $db->establishConnection();
                
				$selQuery = "CALL FetchOngoingTasks('" . $u_id . "','" . $role . "');";
                $res = mysqli_query($conn,$selQuery) or die(mysqli_error());
                while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
					$getOngoingArr[] = $row;
                }	
                mysqli_close($conn);
			}
            catch(Exception $e){
                $this->errorLog[] = 'Exception thrown in getOngoingTasks!';
            }
            return $getOngoingArr;
        }
		
		public function updateTask($u_id,$role,$taskObj){
			$returnObj['status'] = false;
			try{
				//create new project
				$db = new Db('digifactory', 'digiserv_2019');
				$conn = $db->establishConnection();
				$selQuery = "CALL updateTask(
					" . $taskObj['price'] . ",
					" . $taskObj['effort'] . ",
					'" . $taskObj['start_date'] ."',
					'" . $taskObj['end_date'] . "',
					'" . $taskObj['task_status'] . "',
					'" . $taskObj['artifacts_link'] . "',
					'" . $taskObj['pending_with'] . "',
					'" . $taskObj['project_id'] . "'
				);";
				
				$res = mysqli_query($conn,$selQuery) or die(mysqli_error());
				mysqli_close($conn);
				
				if($role == 'SMO'){
					$map_role = 'SMO';
					$db1 = new Db('digifactory', 'digiserv_2019');
					$conn1 = $db1->establishConnection();
					$selQuery1 = "CALL 	Map_AssignedId('".$taskObj['project_id'] ."','" . $u_id . "', '" . $map_role . "');";
					$res1 = mysqli_query($conn1,$selQuery1) or die(mysqli_error());
					mysqli_close($conn1);
				}
				if($role == 'SMO' && isset($taskObj['pm_id'])){
					$map_role = 'PM';
					$db1 = new Db('digifactory', 'digiserv_2019');
					$conn1 = $db1->establishConnection();
					$selQuery1 = "CALL 	Map_AssignedId('".$taskObj['project_id'] ."','" . $taskObj['pm_id'] . "','" . $map_role . "');";
					$res1 = mysqli_query($conn1,$selQuery1) or die(mysqli_error());
					mysqli_close($conn1);
				}
				if($role == 'PM' && isset($taskObj['lm_id'])){
					$map_role = 'LM';
					$db1 = new Db('digifactory', 'digiserv_2019');
					$conn1 = $db1->establishConnection();
					$selQuery1 = "CALL 	Map_AssignedId('".$taskObj['project_id'] ."','" . $taskObj['lm_id'] . "','" . $map_role . "');";
					$res1 = mysqli_query($conn1,$selQuery1) or die(mysqli_error());
					mysqli_close($conn1);
				}
				
				if(isset($taskObj['task_stage'])){
					if($taskObj['task_stage'] != '' && $taskObj['task_stage'] != NULL && $taskObj['task_stage'] != undefined){
						$db1 = new Db('digifactory', 'digiserv_2019');
						$conn1 = $db1->establishConnection();
						$selQuery1 = "CALL updateTaskStage('".$taskObj['project_id'] ."','" . $taskObj['task_stage'] . "');";
						$res1 = mysqli_query($conn1,$selQuery1) or die(mysqli_error());
						mysqli_close($conn1);
					}
				}
				$returnObj['status'] = true;
			}catch(Exception $e){
				$this->errorLog[] = 'Exception thrown in updateTask!';
			}
			return $returnObj;
				
		}
		public function createTask($u_id,$taskArr){
			$returnObj['status'] = false;
			foreach($taskArr as $taskObj){
				try{
					//create new project
					$db = new Db('digifactory', 'digiserv_2019');
					$conn = $db->establishConnection();
					$selQuery = "CALL Create_Task(
						'" . $taskObj['project_name'] . "',
						" . $taskObj['catalogue_type_id'] . ",
						'" . $taskObj['catalogue_type_name'] . "',
						" . $taskObj['task_type_id'] . ",
						'" . $taskObj['task_type_name'] . "',
						'" . $taskObj['task_type_description'] . "',
						" . $taskObj['price'] . ",
						" . $taskObj['effort'] . ",
						'" . $taskObj['start_date']['formatted'] . "',
						'" . $taskObj['end_date']['formatted'] . "',
						'" . $taskObj['task_status'] . "',
						'" . $taskObj['artifacts_link'] . "',
						'" . $taskObj['pending_with'] . "',
						@out
					);";
					
					//echo $selQuery;
					
					$last_insert_id = null;
					$res = mysqli_query($conn,$selQuery) or die(mysqli_error());
					while($row = mysqli_fetch_array($res,MYSQLI_ASSOC)){
						$last_insert_id = $row['tt_id'];
					}	
					mysqli_close($conn);
					if(last_insert_id != null){
						//update project Id
						$p_id = "PRE".$last_insert_id;
						
						$db2 = new Db('digifactory', 'digiserv_2019');
						$conn2 = $db2->establishConnection();
						$selQuery2 = "CALL 	update_project_id(".$last_insert_id.",'" .$p_id. "');";
						$res2 = mysqli_query($conn2,$selQuery2) or die(mysqli_error());
						mysqli_close($conn2);
						
						//update task_assignment table
						$db1 = new Db('digifactory', 'digiserv_2019');
						$conn1 = $db1->establishConnection();
						$selQuery1 = "CALL Requestor_Task_Assign_Update('" . $p_id . "','" . $u_id . "');";
						$res1 = mysqli_query($conn1,$selQuery1) or die(mysqli_error());
						mysqli_close($conn1);
						
						$returnObj['status'] = true;
						
					}
				}
				catch(Exception $e){
					$this->errorLog[] = 'Exception thrown in createTask!';
				}
			}
			return $returnObj;
		}
		
    }
?>