<?php
	error_reporting(E_ALL^(E_WARNING | E_DEPRECATED));
	class Db{
        private $dbConnArr;
        public function __construct($env, $dbName){
            if($env == "digifactory")
				$this->dbConnArr = array(
					'username' => 'admin',
					'password' => 'adminuser',
					'hostname' => 'localhost', //'localhost', 
			    );
				/* $this->dbConnArr = array(
					'username' => 'admin',
					'password' => 'adminuser',
					'hostname' => 'localhost',
					'$env' => $dbName
			    ); */
        }
        
        public function establishConnection(){
            $conn = null;
            $conn = mysqli_connect($this->dbConnArr['hostname'], $this->dbConnArr['username'], $this->dbConnArr['password'],"digiserv_2019");
            if($conn){
                return $conn;
            }
        }
    }
?>


