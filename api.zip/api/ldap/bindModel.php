<?php
//error_reporting(0);

class connectLdap{
    public $userEntries;
	public $connectionStatus;
    
    public function __construct($userid,$password){		
        if($userid == NULL){
            return;
        }
        $ldaprdn  = "cts\\".$userid;
        $ldappass = $password;         
        $ldaphost = '10.242.25.10';
        set_time_limit(0);
        $ldapconn = ldap_connect($ldaphost);
        if ($ldapconn) {
            $ldapbind = ldap_bind($ldapconn, $ldaprdn, $ldappass);     
            $filter = 'sAMAccountName=' . $userid;
            $basedn = "OU=Cognizant,DC=cts,DC=com";
            if ($ldapbind) {
                // Authentication Success
               // $this-> insert_log($userid,"Authentication Success");
                $result = ldap_search($ldapconn, $basedn, $filter) or die("Search error.");
                $this->userEntries = ldap_get_entries($ldapconn, $result);
				$this->userEntries = ldap_get_entries($ldapconn, $result);
				$this->connectionStatus = "Ldap connected";
            } else {
                // Authentication Failure
               //$this-> insert_log($userid,"Authentication Failure");
               $this->userEntries = "Incorrect user credentials";
			   $this->connectionStatus = "error";
            }
        }else{
			$this->userEntries = "Incorrect user credentials";
			$this->connectionStatus = "error";
		}
		
    }
	
     public function getValidLdapUsernamePassword() {
        $userList=[503188,251636];
        foreach ($userList as $key => $value) {
           $queryStr = "CALL ldaplogin_check($value);";
            $this->conn = $GLOBALS['conObj']->establishConnection();
            $resource = mysqli_query($this->conn, $queryStr) or die(mysqli_error($this->conn));
        while ($row = mysqli_fetch_assoc($resource)) {
             echo '<pre>';
             print_r($row);
             exit();
        }
		 mysqli_close($this->conn);
        }
       
         return $userList;       
    }
}
//call this class in your respective php by sending the corresponding to user id variable to it

 	 $lp=new connectLdap(NULL,NULL);
	$details=$lp->getValidLdapUsernamePassword();
    echo "<pre>";
    print_r($details); 

?>