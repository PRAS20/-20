<?php
//error_reporting(0);
class ldapEntries{
    public $userEntries;
    
    public function __construct($userid)
    {
		$ldaprdn_1  = 'cts\503188';
        $ldappass_1 = 'feb-2019'; 
     
        $ldaphost = '10.242.25.10';
        set_time_limit(0);
        $ldapconn = ldap_connect($ldaphost);
        if ($ldapconn) {
            $ldapbind_1 = ldap_bind($ldapconn, $ldaprdn_1, $ldappass_1);
          
            
            $filter = 'sAMAccountName=' . $userid;
            
            $basedn = "OU=Cognizant,DC=cts,DC=com";
            if ($ldapbind_1) {
                $result = ldap_search($ldapconn, $basedn, $filter) or die("Search error.");
                $this->userEntries = ldap_get_entries($ldapconn, $result);
            } else {
                echo "Incorrect user id";
            }
            $this->userEntries = ldap_get_entries($ldapconn, $result);
            // echo '<pre>';
            // print_r($this->userEntries);
            // exit;
        }
    }
    public function getUserEntries()
    {
        return $this->userEntries;
    }
    public function getFullName()
    {
        $full_name = str_replace(' (Cognizant)', '', $this->userEntries[0]['displayname'][0]);
        return $full_name;
    }
    public function getFirstName()
    {
        $full_name   = str_replace(' (Cognizant)', '', $this->userEntries[0]['displayname'][0]);
        $FirstName = explode(",", $full_name);
        return $FirstName[1];
    }
	 public function getLastName()
    {
        $full_name   = str_replace(' (Cognizant)', '', $this->userEntries[0]['displayname'][0]);
        $lastName = explode(",", $full_name);
        return $lastName[0];
    }
    public function getMailid()
    {
        $mail_id = $this->userEntries[0]["mail"][0];
        return $mail_id;
    }
    public function getDepartment()
    {
        $department = $this->userEntries[0]["department"][0];
        return $department;
    }
    public function getProfileImage()
    {
        $profileImage = "data:image/png;base64," . base64_encode($this->userEntries[0]["thumbnailphoto"][0]);
        return $profileImage;
    }
}
//call this class in your respective php by sending the corresponding to user id variable to it

 	// $lp=new ldapEntries(709872);   //id to check
	// $details=$lp->getUserEntries();
	// echo "<pre>";
	// print_r($details);
	//print_r(explode("Band F",explode("&",$details[0]['info'][0])[0]);

?>